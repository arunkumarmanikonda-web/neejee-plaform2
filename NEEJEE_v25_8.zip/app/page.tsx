// NEEJEE Homepage — built to Phase 2 spec
import Link from 'next/link';
import Image from 'next/image';
import { prisma } from '@/lib/prisma';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { ProductCard, type ProductCardData } from '@/components/product/ProductCard';
import { HeroCarousel } from '@/components/home/HeroCarousel';
import { Sparkles, ShieldCheck, Truck, RotateCcw, HandCoins } from 'lucide-react';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

async function getHomeData() {
  try {
    const now = new Date();
    const [founderEdit, newArrivals, allActive, categories, heroBanner] = await Promise.all([
      // v23.40.22 — read latest active hero banner from CMS
      // (added inside Promise.all below)
      prisma.product.findMany({
        where: { status: 'ACTIVE', badges: { has: "FOUNDER'S EDIT" } },
        take: 6, orderBy: { createdAt: 'desc' },
        include: { variants: { select: { inventory: true } } },
      }),
      prisma.product.findMany({
        where: { status: 'ACTIVE' },
        take: 8, orderBy: { createdAt: 'desc' },
        include: { variants: { select: { inventory: true } } },
      }),
      prisma.product.findMany({
        where: { status: 'ACTIVE' },
        take: 4, orderBy: { createdAt: 'asc' },
        include: { variants: { select: { inventory: true } } },
      }),
      prisma.category.findMany({
        where: { products: { some: { status: 'ACTIVE' } } },
        select: { id: true, slug: true, name: true, products: { select: { id: true }, take: 1 } },
        take: 8,
      }),
      // v23.40.23 — ALL active hero banners (scrollable carousel)
      prisma.banner.findMany({
        where: {
          position: 'hero',
          active: true,
          AND: [
            { OR: [{ startsAt: null }, { startsAt: { lte: now } }] },
            { OR: [{ endsAt: null }, { endsAt: { gte: now } }] },
          ],
        },
        orderBy: { order: 'asc' },
      }),
    ]);
    const mapCard = (p: any): ProductCardData => ({
      id: p.id, slug: p.slug, name: p.name, poeticLine: p.poeticLine,
      craft: p.craft, region: p.region,
      mrp: p.mrp, sellingPrice: p.sellingPrice, salePrice: p.salePrice,
      saleStartsAt: p.saleStartsAt, saleEndsAt: p.saleEndsAt,
      images: Array.isArray(p.images) ? p.images : [],
      badges: Array.isArray(p.badges) ? p.badges : [],
      aiTryOnEligible: !!p.aiTryOnEligible,
      inventory: p.variants.reduce((s: number, v: any) => s + (v.inventory || 0), 0),
    });
    // Pick the best 'sarees-like' category for the hero CTA
    const primaryCat = categories.find((c: any) => /sare|women|textile/i.test(c.name + c.slug)) || categories[0];
    return {
      founder: founderEdit.length > 0 ? founderEdit.map(mapCard) : allActive.map(mapCard),
      newArrivals: newArrivals.map(mapCard),
      categories,
      primaryCatSlug: primaryCat?.slug || 'sarees',
      heroBanners: heroBanner as any[],  // v23.40.23 — plural
    };
  } catch (e: any) {
    console.warn('[home] DB query failed:', e.message);
    return { founder: [], newArrivals: [], categories: [], heroBanners: [], error: e.message };
  }
}

// Slugs MUST match either static stories in lib/data.ts or published CMS journal pages.
const JOURNAL_FALLBACK = [
  { slug: 'why-we-built-neejee', title: 'Why we built NEEJEE', excerpt: 'I searched for years for the things I knew existed in India, and found nothing good enough online. So I built it.', image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80' },
  { slug: 'fourteen-days-on-a-loom', title: 'Fourteen days on a loom', excerpt: 'Fourteen days of weaving. One saree. Three generations.', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=800&q=80' },
  { slug: 'how-to-store-a-banarasi', title: 'How to store a Banarasi', excerpt: 'Wrap it in muslin, not plastic. Refold it once a season. Let it breathe.', image: 'https://images.unsplash.com/photo-1583394293214-28a4b6cdf5b2?w=800&q=80' },
];

export default async function HomePage() {
  const data = await getHomeData();

  return (
    <>
      <Header />

      {/* HERO — v23.40.23: scrollable carousel of CMS-driven hero banners with default fallback */}
      <HeroCarousel
        banners={(data as any).heroBanners || []}
        primaryCatSlug={data.primaryCatSlug || 'sarees'}
      />

      {/* TRUST STRIP */}
      <section className="bg-beige border-y border-mitti/20">
        <div className="max-w-8xl mx-auto px-6 lg:px-12 py-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: ShieldCheck, label: 'AUTHENTICITY GUARANTEED', sub: 'Founder-verified craft' },
            { icon: Truck, label: 'FREE SHIPPING', sub: 'Above ₹2,500 across India' },
            { icon: RotateCcw, label: '7-DAY RETURNS', sub: 'No questions asked' },
            { icon: HandCoins, label: 'FAIR TO MAKERS', sub: 'Direct artisan payouts' },
          ].map(t => (
            <div key={t.label} className="flex items-center gap-3">
              <t.icon className="w-6 h-6 text-madder flex-shrink-0" />
              <div>
                <p className="font-ui text-[10px] tracking-widest text-kohl">{t.label}</p>
                <p className="font-italic italic text-mitti text-sm">{t.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FOUNDER'S EDIT — featured products */}
      {data.founder.length > 0 && (
        <section className="max-w-8xl mx-auto px-6 lg:px-12 py-20">
          <div className="flex items-baseline justify-between mb-10">
            <div>
              <p className="label text-madder">THE FIRST EDIT</p>
              <h2 className="font-display text-4xl lg:text-5xl text-kohl mt-2">Founder's Edit</h2>
              <p className="font-italic italic text-mitti mt-2">Hand-picked by Nidhi · Limited drop</p>
            </div>
            <Link href={`/categories/${data.primaryCatSlug || 'sarees'}`} className="font-ui text-xs tracking-widest text-madder hover:underline">
              VIEW ALL →
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 lg:gap-8">
            {data.founder.slice(0, 4).map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {/* FOUNDER NOTE — editorial block, deep multi-region version */}
      <section className="bg-beige py-24">
        <div className="max-w-3xl mx-auto px-6">
          <p className="label text-madder text-center mb-10">A NOTE FROM THE FOUNDER</p>
          <div className="editorial-quote space-y-5">
            <p>NEEJEE began with a question I could not answer for myself: where do I buy the things I know India makes?</p>
            <p>In the north, I knew there was a Banarasi being woven on a pit-loom in Varanasi, a Chikankari shadow-stitch being whispered onto white muslin in Lucknow, a Zardozi being couched in gold next to it. A Phulkari being threaded in vintage pink in Amritsar, a Jutti being stitched in Patiala. A Pashmina being spun from changthangi goat-down in Kashmir, a Kani shawl growing one motif a day on a loom, a Sozni needle following a paisley for three winters. A Chamba Rumal in Himachal, a Kullu shawl, a Likhai-carved door in Uttarakhand, an Aipan drawn on a threshold in red and white.</p>
            <p>In the heart of the country, a Maheshwari being woven on the banks of the Narmada, a Chanderi so light it floats, a Bagh block-print laid out on the river-bed of Madhya Pradesh, a Gond painting in dots and stripes, a Dhokra figure cast in lost-wax in Bastar.</p>
            <p>In Rajasthan, a Gota Patti border being couched in Jaipur, a Bandhani being tied knot-by-knot in Jodhpur, a Leheriya unfurling in waves, a Bagru and a Sanganeri being printed in vegetable dye, a Blue Pottery firing in Jaipur, a Thewa being fused glass-on-gold in Pratapgarh, a Kota Doria so fine you can fold it into a matchbox.</p>
            <p>In Gujarat, a Patola being double-ikat-tied in Patan for six months before a single weft is thrown, an Ajrakh being resist-dyed sixteen times in Kutch, a Rogan being painted with a stylus dipped in castor-oil paint, a Bandhani in Jamnagar, a Kutch mirror-embroidery being stitched by a Rabari woman, a Mata-ni-Pachhedi scroll-painted as a temple.</p>
            <p>In Bihar, a Madhubani being drawn by a woman on the wall of her own home, a Manjusha scroll painted in temple colours, a Sikki grass basket being plaited, a Bhagalpuri tussar being reeled. In Bengal, a Baluchari telling Mahabharata stories in weft, a Jamdani as light as breath, a Kantha stitched from old saris, a Bankura terracotta horse, a Dokra brass figure.</p>
            <p>In the south, a Kalamkari being hand-drawn with a tamarind-twig pen in Srikalahasti, a Machilipatnam Kalamkari being block-printed in Andhra, a Kanchipuram silk being weighted with gold zari, a Pochampalli ikat being tied before it ever touches the loom, a Dharmavaram silk, a Gadwal cotton-silk, a Mangalagiri, a Venkatagiri, a Narayanpet, a Bobbili veena. A Mysore silk, a Bidri inlay of silver on blackened-zinc in Karnataka, a Channapatna lacquered toy, an Ilkal saree. In Tamil Nadu, a Thanjavur painting layered in gold leaf, a Swamimalai bronze cast in the lost-wax tradition of the Cholas, a Madurai Sungudi tie-dye, a Toda red-and-black embroidery in the Nilgiris. In Kerala, an Aranmula Kannadi metal mirror, a Kuthampully cotton with kasavu border, a Screw Pine mat woven on the floor.</p>
            <p>In the northeast, a Muga silk in Assam glowing gold without a single dye, an Eri peace-silk, a Majuli mask carved on the river-island, a Sualkuchi loom never stopping. A Naga shawl on a backstrap loom, a Manipuri Wangkhei Phee, a Mizo Puanchei, a Tripura Risa, an Apatani textile in Arunachal, a Khasi shawl in Meghalaya, a Mishing weave by a riverbank.</p>
            <p>And then the metal, the glass, the clay, the wood. Hyderabad lac bangles being dipped in colour. Firozabad bangles being blown in glass. Moradabad brass being hammered by a man whose grandfather hammered the same metal in the same hand-position. Kannauj attar being distilled from the first monsoon rain. Khurja blue pottery turning on a wheel. Saharanpur rosewood being carved by lamplight.</p>
            <p>But every search led me to either a five-thousand-rupee mass-produced copy, or a thirty-thousand-rupee designer interpretation. Never the thing itself. Never the hands that made it.</p>
            <p>India’s craft is enormous, ancient, and quiet. The noise of glass-fronted malls and over-lit digital aisles was never going to find them.</p>
            <p>One place. One spotlight. One honest price.</p>
            <p>I built a place for all.”</p>
          </div>
          <p className="text-center text-xs tracking-[0.2em] uppercase text-mitti mt-10">Nidhi Chauhan, Founder</p>
        </div>
      </section>

      {/* NEW ARRIVALS */}
      {data.newArrivals.length > 0 && (
        <section className="bg-beige py-20">
          <div className="max-w-8xl mx-auto px-6 lg:px-12">
            <div className="flex items-baseline justify-between mb-10">
              <div>
                <p className="label text-madder">NEW IN</p>
                <h2 className="font-display text-4xl text-kohl mt-2">Just arrived</h2>
              </div>
              <Link href={`/categories/${data.primaryCatSlug || 'sarees'}?sort=newest`} className="font-ui text-xs tracking-widest text-madder hover:underline">
                BROWSE ALL →
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 lg:gap-8">
              {data.newArrivals.slice(0, 4).map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* AI TILE */}
      <section className="max-w-8xl mx-auto px-6 lg:px-12 py-20">
        <div className="bg-kohl text-ivory p-10 lg:p-16 relative overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <p className="label text-banarasi flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> NEEJEE AI
              </p>
              <h2 className="font-display text-4xl lg:text-5xl mt-4">See it on you.<br/>See it in your home.</h2>
              <p className="font-italic italic text-beige/80 text-lg mt-4 max-w-md">
                Try sarees on with the Mirror. Place stoneware in your room with Space. Find the perfect gift with the Concierge.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link href="/ai/mirror" className="btn-primary">TRY THE MIRROR</Link>
                <Link href="/ai/gift" className="font-ui text-xs tracking-widest text-ivory hover:text-banarasi self-center underline underline-offset-4">
                  GIFT CONCIERGE →
                </Link>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {['Mirror', 'Space', 'Gift'].map(s => (
                <div key={s} className="aspect-square bg-mitti/30 flex items-center justify-center">
                  <p className="font-display text-lg text-banarasi">{s}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* STORIES / JOURNAL */}
      <section className="bg-beige py-20">
        <div className="max-w-8xl mx-auto px-6 lg:px-12">
          <div className="text-center mb-12">
            <p className="label text-madder">STORIES</p>
            <h2 className="font-display text-4xl text-kohl mt-2">From the Journal</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {JOURNAL_FALLBACK.map(j => (
              <Link key={j.slug} href={`/journal/${j.slug}`} className="group">
                <div className="aspect-[4/3] bg-ivory overflow-hidden">
                  <Image src={j.image} alt={j.title} width={800} height={600}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <h3 className="font-display text-xl text-kohl mt-4 group-hover:text-madder transition-colors">{j.title}</h3>
                <p className="font-italic italic text-mitti text-sm mt-2">{j.excerpt}</p>
                <p className="font-ui text-xs tracking-widest text-madder mt-3">READ →</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="max-w-3xl mx-auto px-6 py-20 text-center">
        <p className="label text-madder">STAY IN THE TRUNK</p>
        <h2 className="font-display text-3xl text-kohl mt-3">Get our limited drops first.</h2>
        <p className="font-italic italic text-mitti mt-3">No spam. Just craft, once a week.</p>
        <form className="mt-8 flex gap-3 max-w-md mx-auto">
          <input type="email" required placeholder="Your email" className="flex-1 p-3 bg-beige border border-mitti/20 font-ui text-sm" />
          <button type="submit" className="btn-primary">SUBSCRIBE</button>
        </form>
      </section>

      <Footer />
    </>
  );
}
