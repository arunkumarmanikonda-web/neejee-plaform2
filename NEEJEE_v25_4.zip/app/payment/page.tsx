'use client';
import { Suspense, useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Script from 'next/script';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { ShieldCheck } from 'lucide-react';
import { formatINR } from '@/lib/money';

export const dynamic = 'force-dynamic';

function PaymentInner() {
  const sp = useSearchParams();
  const router = useRouter();
  const orderNumber = sp?.get('order');
  const [rzpReady, setRzpReady] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [orderInfo, setOrderInfo] = useState<any>(null);

  useEffect(() => {
    if (!orderNumber) { setError('No order number provided'); return; }
    // Pre-fetch order info to display
    fetch(`/api/orders/${orderNumber}`).then(r => r.json()).then(d => {
      if (d?.order) setOrderInfo(d.order);
    }).catch(() => {});
  }, [orderNumber]);

  const startPayment = async () => {
    if (!orderNumber) return;
    if (!(window as any).Razorpay) { setError('Razorpay not loaded — please refresh'); return; }
    setLoading(true); setError('');
    try {
      const r = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderNumber }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);

      const options = {
        key: d.keyId,
        amount: d.amount,
        currency: d.currency,
        order_id: d.razorpayOrderId,
        name: 'NEEJEE',
        description: `Order ${d.orderNumber}`,
        prefill: { email: orderInfo?.guestEmail || '', contact: orderInfo?.user?.phone || '' },
        theme: { color: '#8B2E2A' },
        handler: async (response: any) => {
          // Verify
          const v = await fetch('/api/razorpay/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...response, orderNumber }),
          });
          const vd = await v.json();
          if (!v.ok) { setError(vd.error || 'Verification failed'); setLoading(false); return; }
          router.push(`/order-confirmation?order=${orderNumber}`);
        },
        modal: {
          ondismiss: () => { setLoading(false); setError('Payment cancelled. You can retry.'); },
        },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (e: any) { setError(e.message); setLoading(false); }
  };

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" onLoad={() => setRzpReady(true)} />
      <Header />
      <section className="max-w-2xl mx-auto px-6 py-20 text-center">
        <p className="label text-madder">PAYMENT</p>
        <h1 className="font-display text-4xl text-kohl mt-3">Complete your order</h1>
        <p className="font-italic italic text-mitti mt-3">{orderNumber}</p>
        <div className="madder-divider mx-auto mt-6"></div>

        {orderInfo && (
          <div className="bg-beige p-8 mt-10 text-left">
            <p className="label text-madder">AMOUNT DUE</p>
            <p className="font-display text-4xl text-kohl mt-2">{formatINR(orderInfo.total)}</p>
            <p className="font-italic italic text-mitti mt-2">Inclusive of all taxes & shipping</p>
          </div>
        )}

        {error && <p className="mt-6 font-ui text-sm text-madder bg-madder/10 p-3">{error}</p>}

        <button onClick={startPayment} disabled={!rzpReady || loading} className="btn-primary mt-8 disabled:opacity-50">
          {loading ? 'OPENING PAYMENT...' : rzpReady ? 'PAY NOW' : 'LOADING...'}
        </button>

        <div className="mt-8 flex items-center justify-center gap-2 text-mitti">
          <ShieldCheck className="w-4 h-4" />
          <p className="font-ui text-xs tracking-widest">SECURED BY RAZORPAY · 256-BIT SSL</p>
        </div>

        <p className="font-italic italic text-mitti text-sm mt-8 max-w-md mx-auto">
          Your card details never touch our servers. We use Razorpay's PCI DSS-certified vault.
          UPI · Cards · Net Banking · Wallets supported.
        </p>
      </section>
      <Footer />
    </>
  );
}

export default function PaymentPage() {
  return (
    <Suspense fallback={<div className="p-12 text-mitti">Loading...</div>}>
      <PaymentInner />
    </Suspense>
  );
}
