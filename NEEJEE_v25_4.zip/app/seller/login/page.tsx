// Seller login — uses the generic /login form, scoped to next=/seller/dashboard.
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default function SellerLoginRedirect({ searchParams }: { searchParams: { token?: string } }) {
  // If a magic-link token is present, pass it through to a future seller magic-link handler.
  // For now, redirect to /login with the destination set.
  const dest = '/login?next=' + encodeURIComponent('/seller/dashboard');
  redirect(dest);
}
