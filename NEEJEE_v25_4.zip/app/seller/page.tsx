// /seller — entry point. Redirects to dashboard or login.
import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export default async function SellerRoot() {
  const session = await getSession();
  if (!session) redirect('/seller/login');
  if (session.role !== 'SELLER' && session.role !== 'SELLER_STAFF' &&
      session.role !== 'ADMIN' && session.role !== 'SUPER_ADMIN') {
    redirect('/login?error=not_a_seller');
  }
  redirect('/seller/dashboard');
}
