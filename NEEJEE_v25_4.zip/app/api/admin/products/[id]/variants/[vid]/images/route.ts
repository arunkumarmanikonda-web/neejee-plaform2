// /api/admin/products/[id]/variants/[vid]/images
// PUT  - replace the variant's images array (admin uploads via existing /api/admin/upload then PUTs here)
// GET  - read current images
//
// Note: admin can also reach Variant.images indirectly by running AI Photo
// Studio scoped to this variant. This endpoint is for direct/manual control.

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

async function gate() {
  const user = await getSession();
  if (!requireRole(user, ['ADMIN', 'SUPER_ADMIN', 'CONTENT_EDITOR'])) {
    return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  }
  return { user };
}

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string; vid: string } }
) {
  const g = await gate();
  if (g.error) return g.error;
  const variant = await prisma.variant.findUnique({
    where: { id: params.vid },
    select: { productId: true, images: true, color: true, size: true, sku: true },
  });
  if (!variant || variant.productId !== params.id) {
    return NextResponse.json({ error: 'Variant not found' }, { status: 404 });
  }
  return NextResponse.json({ variant });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string; vid: string } }
) {
  const g = await gate();
  if (g.error) return g.error;
  try {
    const body = await req.json();
    const images: string[] = Array.isArray(body.images) ? body.images.filter(Boolean) : [];

    const variant = await prisma.variant.findUnique({
      where: { id: params.vid },
      select: { productId: true },
    });
    if (!variant || variant.productId !== params.id) {
      return NextResponse.json({ error: 'Variant not found' }, { status: 404 });
    }

    const updated = await prisma.variant.update({
      where: { id: params.vid },
      data: { images },
      select: { id: true, images: true, color: true, sku: true },
    });
    return NextResponse.json({ ok: true, variant: updated });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Failed' }, { status: 500 });
  }
}
