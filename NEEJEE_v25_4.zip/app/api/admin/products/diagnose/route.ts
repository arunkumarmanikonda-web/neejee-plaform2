// v23.40.20.2 — Product diagnostic endpoint.
// Helps debug "Product not found" issues without needing Vercel logs.
// Usage: /api/admin/products/diagnose?id=cmqf6sn1p0001tbdh290orgp3
//   or:  /api/admin/products/diagnose?id=NEE-THE-0001
//   or:  /api/admin/products/diagnose?id=turkish-mosaic-ottoman-lamp
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession, requireRole } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(request: Request) {
  const user = await getSession();
  if (!requireRole(user, ['ADMIN', 'SUPER_ADMIN', 'CONTENT_EDITOR'])) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const url = new URL(request.url);
  const key = (url.searchParams.get('id') || '').trim();

  if (!key) {
    // List 5 recent products as samples to compare ID format.
    const samples = await prisma.product.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: { id: true, slug: true, sku: true, name: true, status: true },
    });
    const totalCount = await prisma.product.count();
    return NextResponse.json({
      ok: true,
      message: 'Pass ?id=<value> to diagnose. Sample products below.',
      totalCount,
      samples,
    });
  }

  // Try every possible matcher.
  const checks = await Promise.all([
    prisma.product.findUnique({ where: { id: key }, select: { id: true, slug: true, sku: true, name: true, status: true } }).catch(() => null),
    prisma.product.findUnique({ where: { slug: key.toLowerCase() }, select: { id: true, slug: true, sku: true, name: true, status: true } }).catch(() => null),
    prisma.product.findUnique({ where: { sku: key }, select: { id: true, slug: true, sku: true, name: true, status: true } }).catch(() => null),
    prisma.product.findUnique({ where: { sku: key.toUpperCase() }, select: { id: true, slug: true, sku: true, name: true, status: true } }).catch(() => null),
  ]);

  const [byId, bySlug, bySkuRaw, bySkuUpper] = checks;
  const found = byId || bySlug || bySkuRaw || bySkuUpper;

  // Find similar products if nothing matched (catches typos / deletions)
  let similar: any[] = [];
  if (!found) {
    similar = await prisma.product.findMany({
      where: {
        OR: [
          { id: { startsWith: key.slice(0, 8) } },
          { slug: { contains: key.slice(0, 8), mode: 'insensitive' } },
          { sku: { contains: key.slice(0, 8), mode: 'insensitive' } },
          { name: { contains: key.slice(0, 6), mode: 'insensitive' } },
        ],
      },
      take: 5,
      select: { id: true, slug: true, sku: true, name: true, status: true },
    });
  }

  return NextResponse.json({
    ok: !!found,
    searched: key,
    keyLength: key.length,
    keyFormat: /^cm[a-z0-9]{20,}$/i.test(key) ? 'cuid' : /^[0-9a-f]{24}$/i.test(key) ? 'mongodb-objectid' : 'other',
    matches: {
      byId: byId,
      bySlugLower: bySlug,
      bySkuRaw: bySkuRaw,
      bySkuUpper: bySkuUpper,
    },
    found,
    similar,
  });
}
