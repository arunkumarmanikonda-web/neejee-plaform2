// Create a Razorpay order for an existing NEEJEE order
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import Razorpay from 'razorpay';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const { orderNumber } = await request.json();
    if (!orderNumber) return NextResponse.json({ error: 'orderNumber required' }, { status: 400 });

    const order = await prisma.order.findUnique({ where: { orderNumber } });
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    if (order.paymentStatus === 'PAID') {
      return NextResponse.json({ error: 'Already paid' }, { status: 400 });
    }

    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) {
      return NextResponse.json({
        error: 'Razorpay not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to Vercel env vars.',
      }, { status: 500 });
    }

    const rzp = new Razorpay({ key_id: keyId, key_secret: keySecret });
    const rzpOrder = await rzp.orders.create({
      amount: order.total, // already in paise
      currency: 'INR',
      receipt: order.orderNumber,
      notes: { neejeeOrderId: order.id, orderNumber: order.orderNumber },
    });

    // Persist on our Order
    await prisma.order.update({
      where: { id: order.id },
      data: { razorpayOrderId: rzpOrder.id },
    });

    return NextResponse.json({
      razorpayOrderId: rzpOrder.id,
      amount: rzpOrder.amount,
      currency: rzpOrder.currency,
      keyId,
      orderNumber: order.orderNumber,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Razorpay error' }, { status: 500 });
  }
}
