// Verify Razorpay payment signature & mark our Order as PAID
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import crypto from 'crypto';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderNumber } = await request.json();
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !orderNumber) {
      return NextResponse.json({ error: 'Missing payment fields' }, { status: 400 });
    }

    const secret = process.env.RAZORPAY_KEY_SECRET || '';
    if (!secret) {
      // Dev mode: allow without verification but mark as paid
      const order = await prisma.order.update({
        where: { orderNumber },
        data: { paymentStatus: 'PAID', razorpayPaymentId: razorpay_payment_id, status: 'CONFIRMED' },
      });
      // Trigger loyalty processing
      try {
        const { processOrderForLoyalty } = await import('@/lib/loyalty');
        await processOrderForLoyalty(order.id);
      } catch (e: any) { console.warn('[razorpay] loyalty processing failed:', e.message); }
      // v23.40.9 — auto-post to revenue ledger (best-effort, non-blocking)
      try {
        const { postOrderToInvoice } = await import('@/lib/finance/post-order');
        await postOrderToInvoice(order.id);
      } catch (e: any) { console.warn('[razorpay] invoice posting failed:', e.message); }
      return NextResponse.json({ success: true, dev: true, order });
    }

    const expected = crypto
      .createHmac('sha256', secret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expected !== razorpay_signature) {
      // Mark as failed
      await prisma.order.update({
        where: { orderNumber },
        data: { paymentStatus: 'FAILED' },
      }).catch(() => {});
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const order = await prisma.order.update({
      where: { orderNumber },
      data: {
        paymentStatus: 'PAID',
        razorpayPaymentId: razorpay_payment_id,
        razorpayOrderId: razorpay_order_id,
        status: 'CONFIRMED',
      },
    });
    // v23.40.9 — auto-post to revenue ledger (best-effort, non-blocking)
    try {
      const { postOrderToInvoice } = await import('@/lib/finance/post-order');
      await postOrderToInvoice(order.id);
    } catch (e: any) { console.warn('[razorpay] invoice posting failed:', e.message); }
    // Trigger loyalty processing (idempotent)
    try {
      const { processOrderForLoyalty } = await import('@/lib/loyalty');
      await processOrderForLoyalty(order.id);
    } catch (e: any) { console.warn('[razorpay] loyalty processing failed:', e.message); }
    // v23.40.18 — send the customer their branded invoice with the confirmation email
    try {
      const { notify } = await import('@/lib/notifications');
      const { invoiceTokenFor } = await import('@/lib/finance/invoice-token');
      const fullOrder = await prisma.order.findUnique({
        where: { id: order.id },
        include: { user: { select: { id: true, email: true, name: true } } },
      });
      const recipientEmail = fullOrder?.user?.email || fullOrder?.guestEmail;
      const base = process.env.NEXT_PUBLIC_BASE_URL || 'https://neejee.com';
      const invoiceUrl = `${base}/api/orders/${encodeURIComponent(order.orderNumber)}/invoice?token=${invoiceTokenFor(order.id)}`;
      if (recipientEmail) {
        await notify({
          event: 'ORDER_CONFIRMED',
          ...(fullOrder?.userId
            ? { userId: fullOrder.userId }
            : { recipients: [{ email: recipientEmail, name: fullOrder?.guestName || undefined }] }),
          data: {
            orderNumber: order.orderNumber,
            customerName: fullOrder?.user?.name || fullOrder?.guestName || 'friend',
            invoiceUrl,
          },
        });
      }
    } catch (e: any) { console.warn('[razorpay] confirmation email failed:', e.message); }
    return NextResponse.json({ success: true, order });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
