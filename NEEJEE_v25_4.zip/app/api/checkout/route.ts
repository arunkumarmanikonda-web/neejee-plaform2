// Checkout — creates an Order, decrements variant inventory, returns orderNumber
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';
import { generateOrderNumber, calculateGST } from '@/lib/utils';
import { sendEmail, orderPlacedEmail } from '@/lib/email';
import { resolveShipping } from '@/lib/shipping/resolve';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Legacy fallback constants — only used if no ShippingZone rows exist.
// Configurable rates now live in the DB via /admin/settings/shipping.
const GIFT_WRAP_PAISE = 15000;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { items, contact, address, shipping = 'STANDARD', payment = 'RAZORPAY', giftWrap, personalNote, couponCode, gstinCustomer, utm, pointsToRedeem, phoneVerified } = body;

    // v23.37: Guest checkout OTP gate
    // When CHECKOUT_OTP_REQUIRED=true and user is a guest, require phoneVerified=true
    // (set by client after OTP verification flow). Logged-in customers skip.
    const guestSession = await getSession();
    if (process.env.CHECKOUT_OTP_REQUIRED === 'true' && !guestSession) {
      if (!phoneVerified || !contact?.phone) {
        return NextResponse.json({
          error: 'Phone verification required for guest checkout',
          code: 'OTP_REQUIRED',
        }, { status: 401 });
      }
      // Confirm the phone has a recent consumed OTP for checkout_guest purpose
      const { normalizePhone } = await import('@/lib/phone');
      const normalized = normalizePhone(contact.phone) || contact.phone;
      const recent = await prisma.otpCode.findFirst({
        where: {
          phone: normalized,
          purpose: 'checkout_guest',
          consumedAt: { gte: new Date(Date.now() - 10 * 60 * 1000), not: null },
        },
        orderBy: { consumedAt: 'desc' },
      });
      if (!recent) {
        return NextResponse.json({
          error: 'Phone verification expired. Please verify your number again.',
          code: 'OTP_EXPIRED',
        }, { status: 401 });
      }
    }
    // Attribution data (set client-side via lib/analytics.readUtm())
    const attribution = {
      utmSource: utm?.source || null,
      utmMedium: utm?.medium || null,
      utmCampaign: utm?.campaign || null,
      utmContent: utm?.content || null,
      utmTerm: utm?.term || null,
      referrer: utm?.referrer || null,
      landingPage: utm?.landingPage || null,
    };
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'No items in order' }, { status: 400 });
    }
    if (!contact?.email || !contact?.phone) return NextResponse.json({ error: 'Email/phone required' }, { status: 400 });
    if (!address?.name || !address?.line1 || !address?.city || !address?.state || !address?.pincode) {
      return NextResponse.json({ error: 'Incomplete address' }, { status: 400 });
    }
    if (!/^\d{6}$/.test(address.pincode)) return NextResponse.json({ error: 'Invalid pincode' }, { status: 400 });

    const session = guestSession;

    // Server-side recompute prices — never trust client
    let subtotal = 0;
    const verifiedItems: { productId: string; variantId: string | null; quantity: number; price: number; total: number }[] = [];

    for (const item of items) {
      const product: any = await prisma.product.findUnique({
        where: { id: item.productId },
        include: { variants: true },
      });
      if (!product) return NextResponse.json({ error: `Product ${item.productId} not found` }, { status: 400 });
      if (product.status !== 'ACTIVE') return NextResponse.json({ error: `Product ${product.name} unavailable` }, { status: 400 });

      // Determine current effective price (paise) honouring sale window
      const now = new Date();
      let price = product.sellingPrice;
      if (product.salePrice && (!product.saleStartsAt || product.saleStartsAt <= now) && (!product.saleEndsAt || product.saleEndsAt >= now)) {
        price = product.salePrice;
      }

      // Validate variant stock
      let variantId: string | null = null;
      if (item.variantId) {
        const variant = product.variants.find((v: any) => v.id === item.variantId);
        if (!variant) return NextResponse.json({ error: 'Variant not found' }, { status: 400 });
        if (variant.inventory < item.quantity) {
          return NextResponse.json({ error: `Only ${variant.inventory} left of ${product.name}` }, { status: 400 });
        }
        variantId = variant.id;
        if (variant.sellingPrice) price = variant.sellingPrice;
      } else if (product.variants.length > 0) {
        // If product has variants but client didn't pick one, use first in-stock
        const v = product.variants.find((vv: any) => vv.inventory >= item.quantity);
        if (!v) return NextResponse.json({ error: `Out of stock: ${product.name}` }, { status: 400 });
        variantId = v.id;
      }

      const lineTotal = price * item.quantity;
      subtotal += lineTotal;
      verifiedItems.push({ productId: product.id, variantId, quantity: item.quantity, price, total: lineTotal });
    }

    // Gift wrap
    const wrap = giftWrap ? GIFT_WRAP_PAISE : 0;

    // Shipping — resolved from configurable ShippingZone rows (v23.32).
    // Falls back to the legacy hard-coded rates when no zones configured.
    const shippingResolved = await resolveShipping({
      pincode: address.pincode,
      state: address.state,
      subtotalPaise: subtotal,
      mode: shipping === 'EXPRESS' ? 'EXPRESS' : 'STANDARD',
    });
    const shippingPaise = shippingResolved.shippingPaise;

    // Coupon — with userId binding + per-user ledger enforcement
    let discountPaise = 0;
    let appliedCouponId: string | null = null;
    if (couponCode) {
      const coupon = await prisma.coupon.findUnique({
        where: { code: String(couponCode).toUpperCase() },
      });
      if (coupon && coupon.active) {
        const now = new Date();
        const datesOk = (!coupon.validFrom || coupon.validFrom <= now)
          && (!coupon.validTo || coupon.validTo >= now);
        const usageOk = !coupon.maxUses || coupon.usedCount < coupon.maxUses;
        const minOk = !coupon.minCart || subtotal >= coupon.minCart;

        // User binding: only the named user can use a userId-bound coupon
        const userOk = !coupon.userId || (session?.id && coupon.userId === session.id);

        // Per-user ledger: if perUserOnce, this user must not have redeemed before
        let perUserOk = true;
        if (coupon.perUserOnce && session?.id) {
          const used = await prisma.couponRedemption.findUnique({
            where: { couponId_userId: { couponId: coupon.id, userId: session.id } },
          }).catch(() => null);
          if (used) perUserOk = false;
        }

        if (datesOk && usageOk && minOk && userOk && perUserOk) {
          if (coupon.type === 'PERCENT') {
            discountPaise = Math.round((subtotal * coupon.value) / 100);
            if (coupon.maxDiscount && discountPaise > coupon.maxDiscount) discountPaise = coupon.maxDiscount;
          } else if (coupon.type === 'FLAT') {
            discountPaise = Math.min(coupon.value, subtotal);
          }
          appliedCouponId = coupon.id;
        }
      }
    }

    // Points redemption (only if logged in)
    let pointsRedeemed = 0;
    let pointsValuePaise = 0;
    if (pointsToRedeem && pointsToRedeem > 0 && session) {
      const { getCurrentBalance, getSettings } = await import('@/lib/loyalty');
      const [bal, lset] = await Promise.all([getCurrentBalance(session.id), getSettings()]);
      const subtotalForCap = subtotal + wrap + shippingPaise - discountPaise;
      const maxPaise = Math.floor(subtotalForCap * lset.maxRedemptionPct / 100);
      const maxPointsByCap = Math.floor(maxPaise / lset.redemptionValue);
      const requested = Math.max(0, parseInt(pointsToRedeem) || 0);
      pointsRedeemed = Math.min(requested, bal, maxPointsByCap);
      if (pointsRedeemed >= lset.minRedemption) {
        pointsValuePaise = pointsRedeemed * lset.redemptionValue;
      } else {
        pointsRedeemed = 0;
        pointsValuePaise = 0;
      }
    }

    // Tax (inclusive — calc from total for record-keeping)
    const totalBeforeTax = subtotal + wrap + shippingPaise - discountPaise - pointsValuePaise;
    const tax = calculateGST(totalBeforeTax, 5);
    const total = totalBeforeTax;

    // Create address (linked to user if logged in)
    let addressId: string | null = null;
    if (session) {
      const addr = await prisma.address.create({
        data: {
          userId: session.id,
          name: address.name, phone: contact.phone,
          line1: address.line1, line2: address.line2 || null,
          city: address.city, state: address.state, pincode: address.pincode,
          country: 'IN',
        },
      });
      addressId = addr.id;
    }

    // Map payment method
    const paymentMethod = payment === 'COD' ? 'COD' : 'RAZORPAY';
    const paymentStatus = payment === 'COD' ? 'PENDING' : 'PENDING'; // becomes PAID after webhook for online

    const orderNumber = generateOrderNumber();

    const order = await prisma.order.create({
      data: {
        orderNumber,
        userId: session?.id || null,
        addressId,
        guestEmail: session ? null : contact.email,
        guestName: session ? null : address.name,
        subtotal,
        shipping: shippingPaise,
        tax,
        discount: discountPaise,
        total,
        pointsRedeemed,
        pointsValue: pointsValuePaise,
        paymentMethod,
        paymentStatus: paymentStatus as any,
        giftWrap: !!giftWrap,
        personalNote: personalNote || null,
        gstinCustomer: gstinCustomer || null,
        source: 'WEB',
        ...attribution,
        items: {
          create: verifiedItems.map(i => ({
            productId: i.productId,
            variantId: i.variantId || undefined,
            quantity: i.quantity,
            price: i.price,
            total: i.total,
          })),
        },
      },
    });

    // Record coupon usage (atomic-ish: do this after the order is committed)
    if (appliedCouponId) {
      await prisma.coupon.update({
        where: { id: appliedCouponId },
        data: { usedCount: { increment: 1 } },
      }).catch(e => console.warn('[checkout] coupon usedCount failed:', e.message));
      if (session?.id) {
        await prisma.couponRedemption.create({
          data: {
            couponId: appliedCouponId,
            userId: session.id,
            orderId: order.id,
          },
        }).catch(e => console.warn('[checkout] couponRedemption write failed:', e.message));
      }
    }

    // Decrement variant inventory atomically (best effort)
    for (const v of verifiedItems) {
      if (v.variantId) {
        await prisma.variant.update({
          where: { id: v.variantId },
          data: { inventory: { decrement: v.quantity } },
        }).catch(e => console.warn('[checkout] variant decrement failed:', e.message));
      }
    }

    // Send order confirmation email (best-effort, non-blocking)
    const orderForEmail = {
      ...order,
      customerName: address.name,
      items: verifiedItems.map((i, idx) => ({
        ...i,
        name: (items[idx] && items[idx].name) || 'Item',
        subtotal: i.total,
      })),
    };
    // Unified notification: routes through the engine — email always (critical),
    // WhatsApp/SMS gated by env + user opt-in. Backward compatible: still calls
    // the original orderPlacedEmail template for now via the engine fallback.
    try {
      const { notify } = await import('@/lib/notifications');
      const recipients = order.userId
        ? { userId: order.userId }
        : { recipients: [{ email: contact.email, phone: contact.phone, name: contact.name }] };
      notify({
        event: 'ORDER_PLACED',
        ...recipients,
        data: {
          orderNumber: order.orderNumber,
          totalPaise: order.total,
          customerName: contact.name,
        },
        context: {
          type: 'ORDER',
          id: order.id,
          // v23.37: SMS template variable values for DLT registry substitution
          smsVars: {
            orderNumber: order.orderNumber,
            total: Math.round((order.total || 0) / 100).toString(),
          },
        } as any,
      }).catch(e => console.warn('[notify ORDER_PLACED]', e?.message));
    } catch (e: any) {
      console.warn('[checkout] notify failed:', e?.message);
      // Fallback to direct email so users always get *something*
      sendEmail({
        to: contact.email,
        subject: `Order received — ${order.orderNumber}`,
        html: orderPlacedEmail(orderForEmail),
      }).catch(() => {});
    }

    // Mark any pending abandoned cart as RECOVERED for this email
    prisma.abandonedCart.updateMany({
      where: {
        email: contact.email.toLowerCase(),
        recoveredOrderId: null,
        optedOut: false,
      },
      data: {
        recoveredOrderId: order.id,
        recoveredAt: new Date(),
      },
    }).catch(e => console.warn('[checkout] recovery mark failed:', e.message));

    // Debit points if redeemed (idempotent via orderId)
    if (pointsRedeemed > 0 && session) {
      const { redeemPoints } = await import('@/lib/loyalty');
      await redeemPoints({
        userId: session.id,
        points: pointsRedeemed,
        orderId: order.id,
      }).catch(e => console.warn('[checkout] points debit failed:', e.message));
    }

    // For COD, immediately credit loyalty (no payment gateway involved)
    if (payment === 'COD' && session) {
      // COD orders are PENDING until delivery; but we still credit lifetime spend on placement
      // (a real e-comm would credit on delivery — for now we credit on order create for COD)
      // Actually safer: skip loyalty processing here; trigger on PAID webhook for online
      // and on PACKED status for COD.
    }

    return NextResponse.json({
      success: true,
      orderNumber: order.orderNumber,
      orderId: order.id,
      total,
      paymentMethod,
      next: payment === 'COD' ? 'confirmation' : 'payment',
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
