import { NextRequest, NextResponse } from 'next/server';
import { verifyOtp, type OtpPurpose } from '@/lib/otp';

export async function POST(req: NextRequest) {
  try {
    const { phone, purpose, code } = await req.json();
    if (!phone || !purpose || !code) {
      return NextResponse.json({ ok: false, error: 'phone, purpose, code required' }, { status: 400 });
    }
    const result = await verifyOtp({ phone, purpose: purpose as OtpPurpose, code });
    if (!result.ok) {
      return NextResponse.json(result, { status: 400 });
    }
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Verification failed' }, { status: 500 });
  }
}
