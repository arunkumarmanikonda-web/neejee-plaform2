import { NextRequest, NextResponse } from 'next/server';
import { requestOtp, type OtpPurpose } from '@/lib/otp';
import { normalizePhone } from '@/lib/phone';

const VALID_PURPOSES: OtpPurpose[] = [
  'login_customer', 'login_seller', 'login_vendor', 'admin_2fa', 'checkout_guest',
];

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const { phone, purpose } = await req.json();
    if (!phone || !purpose) {
      return NextResponse.json({ ok: false, error: 'phone and purpose required' }, { status: 400 });
    }
    if (!VALID_PURPOSES.includes(purpose)) {
      return NextResponse.json({ ok: false, error: 'Invalid purpose' }, { status: 400 });
    }
    const ipAddress = req.headers.get('x-forwarded-for')?.split(',')[0] || req.headers.get('x-real-ip') || undefined;
    const userAgent = req.headers.get('user-agent') || undefined;

    const result = await requestOtp({ phone, purpose, ipAddress, userAgent });
    if (!result.ok) {
      return NextResponse.json({ ok: false, error: result.error }, { status: 400 });
    }
    // Response shape supports both new clients (OtpLogin component) and legacy
    // /login page (which reads mock/mockCode/phone/expiresInSeconds).
    const normalized = normalizePhone(phone) || phone;
    return NextResponse.json({
      ok: true,
      phone: normalized,
      expiresInSec: result.expiresInSec,
      expiresInSeconds: result.expiresInSec, // legacy alias
      ...(result.devCode ? { devCode: result.devCode, mock: true, mockCode: result.devCode } : {}),
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Failed to request OTP' }, { status: 500 });
  }
}
