// Notification event catalog and types. Single source of truth — every event
// the platform can emit is declared here. Adding a new event = add a row here
// + a template in templates.ts + call notify() from the relevant business code.

export type NotificationEvent =
  // ── Customer order lifecycle ─────────────────────────────────
  | 'ORDER_PLACED'
  | 'ORDER_CONFIRMED'
  | 'ORDER_SHIPPED'
  | 'ORDER_DELIVERED'
  | 'ORDER_CANCELLED'
  | 'ORDER_REFUNDED'
  // v23.37 — marketing / re-engagement
  | 'ABANDONED_CART'
  // ── Purchase Order lifecycle (Neejee ↔ vendor) ───────────────
  | 'PO_SENT'                  // admin sent PO to vendor
  | 'PO_CONFIRMED'             // vendor confirmed → notify admin
  | 'PO_DISPATCHED'            // vendor shipped → notify admin
  | 'PO_RECEIVED'              // admin marked GRN → notify vendor
  | 'PO_CLOSED'                // settled → notify vendor
  | 'PO_CANCELLED'             // notify the other party
  // ── Vendor change requests ───────────────────────────────────
  | 'CHANGE_REQUEST_SUBMITTED' // vendor → admin queue
  | 'CHANGE_REQUEST_APPROVED'  // admin → vendor
  | 'CHANGE_REQUEST_REJECTED'  // admin → vendor
  // ── Vendor documents ─────────────────────────────────────────
  | 'DOC_APPROVED'             // admin → vendor (informational)
  | 'DOC_REJECTED'             // admin → vendor (action required)
  // ── Vendor team ──────────────────────────────────────────────
  | 'TEAM_INVITED'             // (already partly wired in /api/vendor/team)
  // ── Vendor finance ───────────────────────────────────────────
  | 'PAYOUT_SCHEDULED'         // admin → vendor (heads-up)
  | 'PAYOUT_PAID'              // admin → vendor (confirmation)
  // ── Finance module (maker-checker + weekly summary) ──────────
  | 'EXPENSE_PENDING_APPROVAL' // maker → checker (admin/finance)
  | 'EXPENSE_APPROVED'         // checker → maker
  | 'EXPENSE_REJECTED'         // checker → maker
  | 'FINANCE_WEEKLY_SUMMARY'   // cron → ADMIN/SUPER_ADMIN/FINANCE
  // ── Seller portal events ────────────────────────────────
  | 'SELLER_CHANGE_REQUEST_SUBMITTED'  // seller → admin queue
  | 'SELLER_CHANGE_REQUEST_APPROVED'   // admin → seller
  | 'SELLER_CHANGE_REQUEST_REJECTED'   // admin → seller
  | 'SELLER_DOC_UPLOADED'              // seller → admin
  | 'SELLER_DOC_APPROVED'              // admin → seller
  | 'SELLER_DOC_REJECTED'              // admin → seller
  | 'SELLER_TEAM_INVITED'              // owner → invitee
  | 'SELLER_INVENTORY_SUBMITTED'       // seller → admin queue
  | 'SELLER_INVENTORY_UNDER_REVIEW'    // admin → seller
  | 'SELLER_INVENTORY_NEEDS_INFO'      // admin → seller (action needed)
  | 'SELLER_INVENTORY_APPROVED'        // admin → seller
  | 'SELLER_INVENTORY_REJECTED'        // admin → seller
  | 'SELLER_INVENTORY_PUBLISHED'       // admin → seller (live on store!)
  | 'SELLER_PRODUCT_SOLD'              // admin/system → seller (with buyer info when released)
  | 'SELLER_ORDER_READY_TO_DISPATCH'   // admin → seller (buyer info revealed)
  | 'SELLER_PRODUCT_TAKEDOWN'          // admin → seller
  | 'SELLER_PAYOUT_SCHEDULED'          // admin/system → seller
  | 'SELLER_PAYOUT_PAID'               // admin → seller (with UTR)
  // ── Marketing maker-checker ─────────────────────────────
  | 'MARKETING_APPROVAL_REQUESTED'     // operator → manager queue
  | 'MARKETING_APPROVED'               // manager → operator
  | 'MARKETING_REJECTED'               // manager → operator
  | 'MARKETING_WITHDRAWN'              // operator self-withdrew
  // ── Finance — overdue digest ─────────────────────────────
  | 'FINANCE_OVERDUE_DIGEST'           // daily cron → admins
  // ── PO chat (v23.25) ─────────────────────────────────────
  | 'PO_MESSAGE_RECEIVED'              // either party → the other
  // ── Disputes (v23.25) ────────────────────────────────────
  | 'DISPUTE_OPENED'                   // raiser → counterparty + admin
  | 'DISPUTE_COMMENTED'                // any party → the others
  | 'DISPUTE_STATUS_CHANGED'           // actor → the other party
  | 'DISPUTE_RESOLVED'                 // admin → all parties
  // ── Forecast (v23.25) ────────────────────────────────────
  | 'FORECAST_STOCKOUT_WARNING'        // cron → admins (SKU low velocity)
  ;

// Critical events are sent over email regardless of user opt-out (e.g. order
// confirmation, payout). Non-critical events respect the user's emailOptIn flag.
export const CRITICAL_EVENTS: ReadonlySet<NotificationEvent> = new Set<NotificationEvent>([
  'ORDER_PLACED', 'ORDER_CONFIRMED', 'ORDER_SHIPPED', 'ORDER_DELIVERED',
  'ORDER_CANCELLED', 'ORDER_REFUNDED',
  'PO_SENT', 'PO_CONFIRMED', 'PO_DISPATCHED', 'PO_RECEIVED', 'PO_CLOSED', 'PO_CANCELLED',
  'CHANGE_REQUEST_SUBMITTED', 'CHANGE_REQUEST_APPROVED', 'CHANGE_REQUEST_REJECTED',
  'DOC_REJECTED', 'TEAM_INVITED',
  'PAYOUT_SCHEDULED', 'PAYOUT_PAID',
  'EXPENSE_PENDING_APPROVAL', 'EXPENSE_APPROVED', 'EXPENSE_REJECTED',
  'FINANCE_WEEKLY_SUMMARY',
  'SELLER_CHANGE_REQUEST_SUBMITTED', 'SELLER_CHANGE_REQUEST_APPROVED', 'SELLER_CHANGE_REQUEST_REJECTED',
  'SELLER_DOC_UPLOADED', 'SELLER_DOC_APPROVED', 'SELLER_DOC_REJECTED',
  'SELLER_TEAM_INVITED',
  'SELLER_INVENTORY_SUBMITTED', 'SELLER_INVENTORY_UNDER_REVIEW',
  'SELLER_INVENTORY_NEEDS_INFO', 'SELLER_INVENTORY_APPROVED',
  'SELLER_INVENTORY_REJECTED', 'SELLER_INVENTORY_PUBLISHED',
  'SELLER_PRODUCT_SOLD', 'SELLER_ORDER_READY_TO_DISPATCH',
  'SELLER_PRODUCT_TAKEDOWN',
  'SELLER_PAYOUT_SCHEDULED', 'SELLER_PAYOUT_PAID',
  'MARKETING_APPROVAL_REQUESTED', 'MARKETING_APPROVED', 'MARKETING_REJECTED',
  'MARKETING_WITHDRAWN',
  'FINANCE_OVERDUE_DIGEST',
  'PO_MESSAGE_RECEIVED',
  'DISPUTE_OPENED', 'DISPUTE_STATUS_CHANGED', 'DISPUTE_RESOLVED',
  'FORECAST_STOCKOUT_WARNING',
]);

export type NotificationRecipient = {
  userId?: string;       // preferred
  email?: string;        // fallback if no userId
  phone?: string;        // for WhatsApp/SMS
  name?: string;
};

export type NotifyArgs = {
  event: NotificationEvent;
  // Provide either userId(s) (we'll look up email/phone) OR explicit recipients
  userId?: string;
  userIds?: string[];
  recipients?: NotificationRecipient[];
  // Optional: 'admins' broadcasts to all ADMIN + SUPER_ADMIN users
  toAdmins?: boolean;
  // Event-specific data interpolated into templates
  data: Record<string, any>;
  // Optional context for the log row (e.g. {contextType:'PURCHASE_ORDER', contextId:'po_abc'})
  // v23.37: smsVars optionally carries template variable values for DLT SMS substitution
  context?: {
    type: string;
    id: string;
    smsVars?: Record<string, string | number>;
  };
};

export type NotificationChannel = 'EMAIL' | 'WHATSAPP' | 'SMS';

export type SendResult = {
  channel: NotificationChannel;
  recipient: string;
  status: 'SENT' | 'FAILED' | 'SKIPPED';
  providerId?: string;
  error?: string;
};
