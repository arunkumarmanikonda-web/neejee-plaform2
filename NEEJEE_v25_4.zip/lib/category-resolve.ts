// Flexible category resolution — given a URL slug, return Prisma where-clause matching products.
// Handles: department buckets (women/men/etc), exact category slug, craft-as-category, name-fuzzy fallback.
import { prisma } from './prisma';

// Department mapping — maps gendered nav (women/men) and lifestyle nav (home/fragrance/etc) to product fields
// Each department resolves to product names/crafts/categories that match it.
const DEPARTMENT_KEYWORDS: Record<string, { names: string[]; categoryNames: string[] }> = {
  women: {
    names: ['saree', 'sari', 'kurta', 'kurti', 'lehenga', 'dupatta', 'blouse', 'jhumka', 'bangle', 'anklet', 'necklace', 'earring', 'maang', 'tikka', 'bindi', 'choli'],
    categoryNames: ['saree', 'jewellery', 'jewelry', 'dupatta', 'blouse', 'lehenga', 'women'],
  },
  men: {
    names: ['kurta', 'sherwani', 'jodhpuri', 'nehru', 'angrakha', 'pagri', 'turban', 'mojari', 'jutti', 'shawl', 'stole', 'pocket square'],
    categoryNames: ['menswear', 'kurta', 'sherwani', 'men'],
  },
  jewellery: {
    names: ['jhumka', 'bangle', 'anklet', 'necklace', 'earring', 'maang tikka', 'pendant', 'chain', 'ring', 'choker', 'kada'],
    categoryNames: ['jewellery', 'jewelry'],
  },
  accessories: {
    names: ['bag', 'clutch', 'purse', 'wallet', 'scarf', 'stole', 'shawl', 'belt', 'watch', 'sunglass', 'pouch', 'tote', 'sling', 'pocket square'],
    categoryNames: ['accessories', 'accessory', 'bag', 'scarf', 'stole'],
  },
  home: {
    names: ['cushion', 'throw', 'rug', 'dhurrie', 'block print', 'tapestry', 'table', 'planter', 'lamp', 'mirror', 'wall'],
    categoryNames: ['home', 'home decor', 'textile', 'furnishing'],
  },
  fragrance: {
    names: ['attar', 'ittar', 'perfume', 'scent', 'oil', 'incense', 'agarbatti', 'dhoop'],
    categoryNames: ['fragrance', 'perfume', 'attar'],
  },
  gifting: {
    names: ['gift', 'box', 'set', 'hamper'],
    categoryNames: ['gift', 'gifting'],
  },
};

export async function resolveCategoryWhere(slug: string): Promise<{
  where: any;
  matchedCategory: { id: string; slug: string; name: string } | null;
  matchMode: 'slug' | 'craft' | 'name-fuzzy' | 'department' | 'all';
}> {
  if (!slug || slug === 'all') {
    return { where: { status: 'ACTIVE' }, matchedCategory: null, matchMode: 'all' };
  }

  // 0. Department buckets (women, men, home, jewellery, fragrance, gifting)
  const slugLower = slug.toLowerCase();
  const dept = DEPARTMENT_KEYWORDS[slugLower];
  if (dept) {
    const orClauses: any[] = [];
    dept.names.forEach(kw => {
      orClauses.push({ name: { contains: kw, mode: 'insensitive' } });
      orClauses.push({ craft: { contains: kw, mode: 'insensitive' } });
      orClauses.push({ material: { contains: kw, mode: 'insensitive' } });
    });
    dept.categoryNames.forEach(cn => {
      orClauses.push({ category: { name: { contains: cn, mode: 'insensitive' } } });
      orClauses.push({ category: { slug: { contains: cn, mode: 'insensitive' } } });
    });
    return {
      where: { status: 'ACTIVE', OR: orClauses },
      matchedCategory: { id: '', slug, name: slug.charAt(0).toUpperCase() + slug.slice(1) },
      matchMode: 'department',
    };
  }

  // 1. Exact slug match on Category
  const cat = await prisma.category.findFirst({
    where: { slug: { equals: slug, mode: 'insensitive' } },
    select: { id: true, slug: true, name: true },
  });
  if (cat) {
    return {
      where: { status: 'ACTIVE', categoryId: cat.id },
      matchedCategory: cat,
      matchMode: 'slug',
    };
  }

  // 2. Treat slug as craft (e.g. 'banarasi', 'phulkari')
  const craftMatch = await prisma.product.findFirst({
    where: { status: 'ACTIVE', craft: { equals: slug, mode: 'insensitive' } },
    select: { id: true },
  });
  if (craftMatch) {
    return {
      where: { status: 'ACTIVE', craft: { equals: slug, mode: 'insensitive' } },
      matchedCategory: { id: '', slug, name: slug.charAt(0).toUpperCase() + slug.slice(1) },
      matchMode: 'craft',
    };
  }

  // 3. Fuzzy match on category name or product name/craft (e.g. 'sarees' → match products containing 'saree')
  const fuzzy = slug.replace(/s$/, ''); // strip trailing 's' (plural)
  const fuzzyCat = await prisma.category.findFirst({
    where: { name: { contains: fuzzy, mode: 'insensitive' } },
    select: { id: true, slug: true, name: true },
  });
  if (fuzzyCat) {
    return {
      where: { status: 'ACTIVE', categoryId: fuzzyCat.id },
      matchedCategory: fuzzyCat,
      matchMode: 'name-fuzzy',
    };
  }

  // 4. Last resort: match products whose name/craft/material contains the term
  return {
    where: {
      status: 'ACTIVE',
      OR: [
        { craft: { contains: fuzzy, mode: 'insensitive' } },
        { name: { contains: fuzzy, mode: 'insensitive' } },
        { material: { contains: fuzzy, mode: 'insensitive' } },
        { category: { name: { contains: fuzzy, mode: 'insensitive' } } },
      ],
    },
    matchedCategory: { id: '', slug, name: slug.charAt(0).toUpperCase() + slug.slice(1) },
    matchMode: 'name-fuzzy',
  };
}
