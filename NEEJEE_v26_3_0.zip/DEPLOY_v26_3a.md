# NEEJEE v23.40.27.0 (Wave 26.3a) — Deployment Guide

## What this wave delivers

1. **Bug fix (NEEJEE-263)**: Prepaid orders no longer created until payment is verified. Customers who abandon at the Razorpay modal no longer receive a stray "Order received" email, and no stray Order row appears in `/admin/orders`.
2. **Cart status machine** for abandoned-trunk tracking.
3. **AI-personalized recovery emails** at T+1h, T+24h (10% gift), T+72h (15% farewell gift).
4. **Telecaller handoff** at T+7d.
5. **Admin views**: `/admin/abandoned-carts`, `/admin/telecaller`, `/admin/recovery-settings`.
6. **Admin orders** default view hides `CANCELLED_BUG`.
7. **One-time cleanup** of Nidhi's stray order and any historical strays.

---

## Files in this zip

```
prisma/SPRINT_26_3A_MIGRATION.sql        ← schema migration (run FIRST)
prisma/SPRINT_26_3A_CLEANUP.sql          ← Nidhi + historic strays cleanup (run SECOND)

app/api/checkout/route.ts                ← REPLACE (split COD vs PREPAID)
app/api/checkout/abandon/route.ts        ← NEW (beacon target)
app/api/checkout/snapshot/[id]/route.ts  ← NEW (payment page info)
app/api/checkout/recover/[id]/route.ts   ← NEW (recovery link handler)
app/api/razorpay/create-order/route.ts   ← REPLACE (snapshot-based)
app/api/razorpay/verify/route.ts         ← REPLACE (Order born here)
app/api/cron/cart-recovery/route.ts      ← NEW (cron handler)
app/api/admin/abandoned-carts/route.ts   ← NEW
app/api/admin/abandoned-carts/[id]/route.ts ← NEW
app/api/admin/telecaller/route.ts        ← NEW
app/api/admin/recovery-settings/route.ts ← NEW
app/api/admin/orders/route.ts            ← REPLACE (filter CANCELLED_BUG)

app/payment/page.tsx                     ← REPLACE (snapshot flow)
app/(shop)/checkout/page.tsx.PATCH.md    ← Manual patch instructions (3 small edits)
app/admin/abandoned-carts/page.tsx       ← NEW
app/admin/telecaller/page.tsx            ← NEW
app/admin/recovery-settings/page.tsx     ← NEW
app/recovery/opt-out/page.tsx            ← NEW

lib/recovery/ai-copy.ts                  ← NEW (OpenAI personalization)
lib/recovery/discount.ts                 ← NEW (coupon generation)
lib/email/templates/recovery-shared.ts   ← NEW
lib/email/templates/recovery-t1h.ts      ← NEW
lib/email/templates/recovery-t24h.ts     ← NEW
lib/email/templates/recovery-t72h.ts     ← NEW
lib/email/templates/telecaller-handoff.ts ← NEW

vercel.json                              ← MERGE (adds cron entry)
```

---

## Deployment order

### Step 1 — Apply database migrations (Supabase SQL editor)

```sql
-- 1. Run this first:
\i prisma/SPRINT_26_3A_MIGRATION.sql
-- Confirm verification queries report:
--   AbandonedCart cols added: 15
--   Order cols added: 2
--   RecoverySettings ready: 1

-- 2. Then run the cleanup:
\i prisma/SPRINT_26_3A_CLEANUP.sql
-- Verification will show:
--   PREVIEW: bug-strays to be cancelled: (some N)
--   AFTER: cancelled bug-strays: N
--   AFTER: abandoned carts ready for recovery: N
```

### Step 2 — Drop in the code files

In your local `neejee-v6` working copy:

```powershell
cd C:\Users\arunk\OneDrive\Desktop\neejee-v6
# Extract the zip then xcopy each file into place,
# OR Robocopy /E from the extracted folder into the project root.
```

**The checkout page (`app/(shop)/checkout/page.tsx`) is a manual 3-edit patch** —
see `app/(shop)/checkout/page.tsx.PATCH.md` in the zip. Two snippets to replace
and one new useEffect to add. Total: ~30 lines changed.

### Step 3 — Merge vercel.json

If you already have a `vercel.json` with other crons or settings, merge the
`crons` array. Otherwise, drop the file in as-is.

### Step 4 — Set environment variables (Vercel dashboard)

```
CRON_SECRET=<generate a long random string>  ← REQUIRED
TELECALLER_TEAM_EMAIL=<your telecaller team's inbox>  ← optional, defaults to EMAIL_FROM
OPENAI_API_KEY=<existing key>  ← required for AI personalization, falls back to template if missing
OPENAI_MODEL=gpt-4o-mini       ← optional override

# Existing vars that must already be set:
RESEND_API_KEY=...
EMAIL_FROM=NEEJEE <hello@neejee.com>
RAZORPAY_KEY_ID=...
RAZORPAY_KEY_SECRET=...
RAZORPAY_WEBHOOK_SECRET=...
NEXT_PUBLIC_BASE_URL=https://www.neejee.com
```

### Step 5 — Run Prisma generate and deploy

```powershell
npx prisma generate
vercel --prod --force
```

Note: This wave doesn't change `prisma/schema.prisma`. All schema changes are
applied via the raw-SQL migration above. The `prisma generate` step still runs
to refresh the client types against the database state Prisma will introspect
on the next pull.

If you prefer to fully sync Prisma with the new columns, run:
```
npx prisma db pull
npx prisma generate
```

---

## Smoke test checklist (do these in production after deploy)

### Test 1 — Prepaid abandonment (the original bug)
1. Add an item to cart, go to `/checkout`, fill address, select **Razorpay**.
2. Click Pay → Razorpay modal opens. **CLOSE the modal without paying.**
3. Confirm:
   - ✅ No Order row appears in `/admin/orders`
   - ✅ No "Order received" email arrives
   - ✅ A row appears in `/admin/abandoned-carts` with stage 0
   - ✅ `nextActionAt` is set to ~1 hour from now

### Test 2 — Prepaid completion
1. Repeat above but actually complete payment with a Razorpay test card.
2. Confirm:
   - ✅ Order appears in `/admin/orders` with status=CONFIRMED, paymentStatus=PAID
   - ✅ Confirmation email arrives
   - ✅ The abandoned cart row is marked `recoveredOrderId=<order id>`

### Test 3 — COD (must be unchanged)
1. Add item, checkout, select COD, place order.
2. Confirm:
   - ✅ Order created with status=PLACED, paymentStatus=PENDING, paymentMethod=COD
   - ✅ "Order received" email arrives immediately

### Test 4 — Recovery cron (simulate)
1. In Supabase, manually update an abandoned cart's `nextActionAt = NOW()` and `createdAt = NOW() - INTERVAL '40 minutes'` (past the grace period).
2. Hit the cron endpoint manually:
   ```bash
   curl -H "Authorization: Bearer <CRON_SECRET>" https://www.neejee.com/api/cron/cart-recovery
   ```
3. Confirm:
   - ✅ Email arrives (T+1h template, gentle voice, no discount)
   - ✅ `recoveryStage` advances to 1
   - ✅ `nextActionAt` advances to 23 hours from now (T+24h)

### Test 5 — Admin views
1. Visit `/admin/abandoned-carts` → list view with stage badges, summary tiles.
2. Visit `/admin/telecaller` → empty (until a row hits stage 4) or populated with handoff queue.
3. Visit `/admin/recovery-settings` → edit cadence/discount/AI toggle, save, reload.

### Test 6 — Opt-out
1. Open the footer link in any recovery email or hit `/recovery/opt-out?cart=<id>` manually.
2. Confirm: cart is marked `optedOut=true` and `nextActionAt=null`. Cron skips it.

---

## Rollback plan

If anything goes catastrophically wrong after deploy:

```sql
-- 1. Revert checkout/route.ts to pre-26.3a (creates Order for prepaid too).
--    Restore from your previous deployment artifact.

-- 2. The migration SQL is additive. To roll back:
ALTER TABLE "AbandonedCart" DROP COLUMN IF EXISTS "recoveryStage" CASCADE;
-- (etc — but in practice you should leave additive columns in place; they
-- don't break older code.)

-- 3. The CANCELLED_BUG enum value cannot be removed without rebuilding the
--    enum. Leave it in place — older code ignores it.
```

In practice this wave is **safe to roll forward only**: the schema additions
don't break the old code, and the new code can coexist with old data.

---

## Out of scope this wave (Wave 26.3b will add)

- SMS recovery channel (DLT-compliant)
- WhatsApp recovery channel (Meta-approved templates)
- A/B testing infrastructure
- Statistical significance reporting

Sprint 26.3b is blocked on DLT and Meta approval workflows (typically 7–14 days).
Initiate those externally now and the code will land when approvals come back.
