// app/api/cron/cart-recovery/route.ts
// v26.3a — Vercel Cron handler. Runs every 15 minutes.
// Picks up AbandonedCart rows whose nextActionAt <= now, advances them
// through the recovery stages (1=T+1h, 2=T+24h, 3=T+72h, 4=T+7d handoff).
//
// Auth: requires Authorization: Bearer <CRON_SECRET>.
// Vercel automatically attaches this header for crons defined in vercel.json.

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { generateRecoveryCopy } from '@/lib/recovery/ai-copy';
import { ensureStageCoupon } from '@/lib/recovery/discount';
import { recoveryT1hEmail } from '@/lib/email/templates/recovery-t1h';
import { recoveryT24hEmail } from '@/lib/email/templates/recovery-t24h';
import { recoveryT72hEmail } from '@/lib/email/templates/recovery-t72h';
import { telecallerHandoffEmail } from '@/lib/email/templates/telecaller-handoff';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export const maxDuration = 60;

const HOURS = 60 * 60 * 1000;

function authorized(req: Request): boolean {
  const expected = process.env.CRON_SECRET;
  if (!expected) {
    console.warn('[cron] CRON_SECRET not set — refusing');
    return false;
  }
  const got = req.headers.get('authorization') || '';
  return got === `Bearer ${expected}`;
}

export async function GET(req: Request) {
  if (!authorized(req)) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  return run();
}

export async function POST(req: Request) {
  if (!authorized(req)) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  return run();
}

async function run() {
  const startedAt = Date.now();
  const settings = await prisma.recoverySettings.findUnique({ where: { id: 'default' } } as any).catch(() => null);
  const cadence = (settings as any)?.cadenceHours || { stage1: 1, stage2: 24, stage3: 72, stage4: 168 };
  const percents = (settings as any)?.discountPercents || { stage2: 10, stage3: 15 };
  const aiEnabled = (settings as any)?.aiEnabled ?? true;
  const handoffEnabled = (settings as any)?.telecallerHandoffEnabled ?? true;
  const graceMinutes = (settings as any)?.abandonGraceMinutes || 30;

  // Find rows due for processing
  const now = new Date();
  const graceThreshold = new Date(now.getTime() - graceMinutes * 60 * 1000);

  const due = await prisma.abandonedCart.findMany({
    where: {
      recoveredOrderId: null,
      optedOut: false,
      nextActionAt: { lte: now },
      createdAt: { lte: graceThreshold },
      recoveryStage: { lt: 4 },
    } as any,
    orderBy: { nextActionAt: 'asc' },
    take: 100, // batch cap
  });

  const base = process.env.NEXT_PUBLIC_BASE_URL || 'https://neejee.com';
  const results: any[] = [];

  for (const cart of due) {
    try {
      const stageToFire = (cart.recoveryStage + 1) as 1 | 2 | 3 | 4;

      // Parse cart snapshot for items
      let snapshotItems: any[] = [];
      try {
        const data = cart.itemsJson ? JSON.parse(cart.itemsJson) : {};
        snapshotItems = data?.verifiedItems || data?.items || [];
      } catch { /* swallow */ }

      const renderItems = snapshotItems.slice(0, 4).map((i: any) => ({
        name: i.name || 'Item',
        craft: i.craft || null,
        region: i.region || null,
        quantity: i.quantity || 1,
        price: i.price || 0,
      }));

      const recoverUrl = `${base}/checkout?recover=${cart.id}`;
      const optOutUrl = `${base}/recovery/opt-out?cart=${cart.id}`;
      const totalRupees = Math.round(cart.subtotal / 100);

      // ── STAGE 4: Telecaller handoff (internal only) ────────────────
      if (stageToFire === 4) {
        if (!handoffEnabled) {
          // Just mark stage advanced
          await prisma.abandonedCart.update({
            where: { id: cart.id },
            data: { recoveryStage: 4, nextActionAt: null, lastRemindedAt: now } as any,
          });
          results.push({ id: cart.id, stage: 4, status: 'handoff-disabled' });
          continue;
        }

        const teamEmail = process.env.TELECALLER_TEAM_EMAIL || process.env.EMAIL_FROM || 'hello@neejee.com';
        const craftRegions = Array.from(new Set(
          snapshotItems
            .map((i: any) => [i.craft, i.region].filter(Boolean).join(' · '))
            .filter((s: string) => s.length > 0)
        )) as string[];

        const tpl = telecallerHandoffEmail({
          cartId: cart.id,
          customerName: cart.customerName,
          customerEmail: cart.email,
          customerPhone: (cart as any).phone,
          itemCount: cart.itemCount,
          subtotalPaise: cart.subtotal,
          craftRegions,
          adminUrl: `${base}/admin/telecaller`,
        });

        await sendEmail({ to: teamEmail, subject: tpl.subject, html: tpl.html });

        await prisma.abandonedCart.update({
          where: { id: cart.id },
          data: {
            recoveryStage: 4,
            nextActionAt: null, // no more automated actions
            remindersSent: { increment: 1 },
            lastRemindedAt: now,
            telecallerStatus: null, // ready for pickup
          } as any,
        });

        results.push({ id: cart.id, stage: 4, status: 'handed-off' });
        continue;
      }

      // ── STAGES 1, 2, 3 → customer-facing emails ─────────────────────
      let discountCode: string | undefined;
      let discountPercent: number | undefined;
      let validHours: number | undefined;

      if (stageToFire === 2) {
        const { code, percent } = await ensureStageCoupon(
          {
            id: cart.id,
            userId: cart.userId,
            email: cart.email,
            discountCode: (cart as any).discountCode || null,
            discountPercent: (cart as any).discountPercent || null,
          },
          2,
          {
            percent2: percents.stage2,
            percent3: percents.stage3,
            validHours2: cadence.stage3 - cadence.stage2, // expires when stage 3 fires
            validHours3: 48,
          }
        );
        discountCode = code;
        discountPercent = percent;
        validHours = cadence.stage3 - cadence.stage2;
      } else if (stageToFire === 3) {
        const { code, percent } = await ensureStageCoupon(
          {
            id: cart.id,
            userId: cart.userId,
            email: cart.email,
            discountCode: null, // force new code for stage 3
            discountPercent: null,
          },
          3,
          {
            percent2: percents.stage2,
            percent3: percents.stage3,
            validHours2: 48,
            validHours3: cadence.stage4 - cadence.stage3,
          }
        );
        discountCode = code;
        discountPercent = percent;
        validHours = cadence.stage4 - cadence.stage3;
      }

      // AI copy
      let aiCopy: any = undefined;
      if (aiEnabled) {
        try {
          aiCopy = await generateRecoveryCopy({
            customerName: cart.customerName,
            items: renderItems,
            stage: stageToFire,
            discountPercent,
            discountCode,
            totalRupees,
          });
        } catch (e: any) {
          console.warn('[cron] ai copy failed:', e.message);
        }
      }

      // Render email
      let tpl: { subject: string; html: string };
      if (stageToFire === 1) {
        tpl = recoveryT1hEmail({
          customerName: cart.customerName,
          items: renderItems,
          subtotalPaise: cart.subtotal,
          recoverUrl,
          optOutUrl,
          aiCopy,
        });
      } else if (stageToFire === 2) {
        tpl = recoveryT24hEmail({
          customerName: cart.customerName,
          items: renderItems,
          subtotalPaise: cart.subtotal,
          recoverUrl,
          optOutUrl,
          aiCopy,
          discountCode: discountCode!,
          discountPercent: discountPercent!,
          validHours: validHours!,
        });
      } else {
        tpl = recoveryT72hEmail({
          customerName: cart.customerName,
          items: renderItems,
          subtotalPaise: cart.subtotal,
          recoverUrl,
          optOutUrl,
          aiCopy,
          discountCode: discountCode!,
          discountPercent: discountPercent!,
          validHours: validHours!,
        });
      }

      // Send
      const sendRes = await sendEmail({ to: cart.email, subject: tpl.subject, html: tpl.html });

      // Compute next action
      const nextHours = stageToFire === 1 ? cadence.stage2 - cadence.stage1
                      : stageToFire === 2 ? cadence.stage3 - cadence.stage2
                      : cadence.stage4 - cadence.stage3;
      const nextActionAt = new Date(now.getTime() + nextHours * HOURS);

      await prisma.abandonedCart.update({
        where: { id: cart.id },
        data: {
          recoveryStage: stageToFire,
          nextActionAt,
          remindersSent: { increment: 1 },
          lastRemindedAt: now,
          aiCopyJson: aiCopy ? aiCopy : undefined,
        } as any,
      });

      results.push({
        id: cart.id,
        stage: stageToFire,
        status: sendRes.ok ? 'sent' : 'send-failed',
        ai: aiCopy?.generatedBy,
      });
    } catch (e: any) {
      console.warn('[cron] cart', cart.id, 'failed:', e?.message);
      results.push({ id: cart.id, error: e.message });
    }
  }

  return NextResponse.json({
    ok: true,
    processed: results.length,
    elapsedMs: Date.now() - startedAt,
    results,
  });
}
