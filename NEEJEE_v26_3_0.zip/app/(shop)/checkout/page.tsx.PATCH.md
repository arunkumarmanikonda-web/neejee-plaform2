# Patch instructions for app/(shop)/checkout/page.tsx — v26.3a

This page is 390 lines and the only thing that needs to change is the
submit handler (currently at lines ~118–148 in v26.2.x) and adding an
abandonment beacon hook. Below is the diff in two patches.

## PATCH 1 — Replace the submit handler block

**Find** (around line 118):

```tsx
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: items.map(i => ({
            productId: i.productId,
            variantId: i.variantId,
            quantity: i.quantity,
            price: i.product.sellingPrice,
          })),
          contact, address, shipping, payment,
          giftWrap, personalNote,
          couponCode,
          gstinCustomer: wantGstInvoice ? gstinCustomer : null,
          utm: readUtm() || undefined,
          pointsToRedeem,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Order failed');
      clear();
      if (payment === 'COD') {
        router.push(`/order-confirmation?order=${d.orderNumber}`);
      } else {
        router.push(`/payment?order=${d.orderNumber}`);
      }
    } catch (e: any) { setError(e.message); setSubmitting(false); }
  };
```

**Replace with**:

```tsx
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: items.map(i => ({
            productId: i.productId,
            variantId: i.variantId,
            quantity: i.quantity,
            price: i.product.sellingPrice,
          })),
          contact, address, shipping, payment,
          giftWrap, personalNote,
          couponCode,
          gstinCustomer: wantGstInvoice ? gstinCustomer : null,
          utm: readUtm() || undefined,
          pointsToRedeem,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Order failed');

      // v26.3a — Two different flows
      if (payment === 'COD') {
        // COD: real order was created server-side, clear cart, go to confirmation
        clear();
        router.push(`/order-confirmation?order=${d.orderNumber}`);
      } else {
        // PREPAID: server returned a snapshotId, NOT an orderNumber.
        // Do NOT clear cart yet — only clear after /verify confirms payment.
        // Stash snapshotId so payment page + abandonment beacon can use it.
        if (d.snapshotId) {
          try { sessionStorage.setItem('neejee_checkout_snapshot', d.snapshotId); } catch {}
        }
        router.push(`/payment?snapshot=${d.snapshotId}`);
      }
    } catch (e: any) { setError(e.message); setSubmitting(false); }
  };
```

## PATCH 2 — Add abandonment beacon hook

**Find** (the line `export default function CheckoutPage() {`) and right after
the existing `useEffect`s, add this new hook:

```tsx
  // v26.3a — Fire abandonment beacon if user leaves the checkout page
  // before completing payment. Cron will then process the snapshot at T+1h.
  useEffect(() => {
    const handler = () => {
      try {
        const id = sessionStorage.getItem('neejee_checkout_snapshot');
        if (!id) return;
        const blob = new Blob([JSON.stringify({ snapshotId: id, step })], {
          type: 'application/json',
        });
        navigator.sendBeacon('/api/checkout/abandon', blob);
      } catch { /* swallow */ }
    };
    window.addEventListener('beforeunload', handler);
    window.addEventListener('pagehide', handler);
    return () => {
      window.removeEventListener('beforeunload', handler);
      window.removeEventListener('pagehide', handler);
    };
  }, [step]);
```

## PATCH 3 — `app/payment/page.tsx` (the Razorpay redirect step)

If your `app/payment/page.tsx` currently reads `?order=NXX` and looks the
order up, change it to read `?snapshot=...`, call /api/razorpay/create-order
with `{ snapshotId }`, and on Razorpay success call /api/razorpay/verify
with `{ snapshotId, razorpay_order_id, razorpay_payment_id, razorpay_signature }`.

After /verify returns success, do:
```tsx
clear(); // empty the cart
sessionStorage.removeItem('neejee_checkout_snapshot');
router.push(`/order-confirmation?order=${data.order.orderNumber}`);
```

If you'd like, I can provide a full replacement payment page file too.
