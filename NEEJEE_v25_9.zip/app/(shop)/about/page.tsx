import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';

export const metadata = { title: 'About · NEEJEE', description: 'NEEJEE is the place built for India\'s quiet, generational craft. Weavers, potters, carpenters, metalsmiths, perfumers and the hands behind every piece. Founded by Nidhi Chauhan.' };

export default function AboutPage() {
  return (
    <>
      <Header />
      <section className="max-w-3xl mx-auto px-6 py-20 text-center">
        <p className="label text-madder mb-4">ABOUT</p>
        <h1 className="font-display text-5xl md:text-6xl text-kohl leading-tight">Why we exist.</h1>
        <div className="madder-divider mx-auto mt-8"></div>
        <p className="editorial-pullquote mt-12">
          &ldquo;The rarest things in India are rarely the hardest to make. They are simply the hardest to find.&rdquo;
        </p>
        <p className="text-center text-xs tracking-[0.2em] uppercase text-mitti mt-8">Nidhi Chauhan, Founder</p>
      </section>

      <section className="max-w-3xl mx-auto px-6 py-12 font-body text-lg text-kohl/85 leading-relaxed space-y-6">
        <p>NEEJEE began with a question I could not answer for myself: where do I buy the things I know India makes?</p>
        <p>In the north, I knew there was a Banarasi being woven on a pit-loom in Varanasi, a Chikankari shadow-stitch being whispered onto white muslin in Lucknow, a Zardozi being couched in gold next to it. A Phulkari being threaded in vintage pink in Amritsar, a Jutti being stitched in Patiala. A Pashmina being spun from changthangi goat-down in Kashmir, a Kani shawl growing one motif a day on a loom, a Sozni needle following a paisley for three winters. A Chamba Rumal in Himachal, a Kullu shawl, a Likhai-carved door in Uttarakhand, an Aipan drawn on a threshold in red and white.</p>
        <p>In the heart of the country, a Maheshwari being woven on the banks of the Narmada, a Chanderi so light it floats, a Bagh block-print laid out on the river-bed of Madhya Pradesh, a Gond painting in dots and stripes, a Dhokra figure cast in lost-wax in Bastar. In Rajasthan, a Gota Patti border being couched in Jaipur, a Bandhani being tied knot-by-knot in Jodhpur, a Leheriya unfurling in waves, a Bagru and a Sanganeri being printed in vegetable dye, a Blue Pottery firing in Jaipur, a Thewa being fused glass-on-gold in Pratapgarh, a Kota Doria so fine you can fold it into a matchbox.</p>
        <p>In Gujarat, a Patola being double-ikat-tied in Patan for six months before a single weft is thrown, an Ajrakh being resist-dyed sixteen times in Kutch, a Rogan being painted with a stylus dipped in castor-oil paint, a Bandhani in Jamnagar, a Kutch mirror-embroidery being stitched by a Rabari woman, a Mata-ni-Pachhedi scroll-painted as a temple. In Bihar, a Madhubani being drawn by a woman on the wall of her own home, a Manjusha scroll painted in temple colours, a Sikki grass basket being plaited, a Bhagalpuri tussar being reeled. In Bengal, a Baluchari telling Mahabharata stories in weft, a Jamdani as light as breath, a Kantha stitched from old saris, a Bankura terracotta horse, a Dokra brass figure.</p>
        <p>In the south, a Kalamkari being hand-drawn with a tamarind-twig pen in Srikalahasti, a Machilipatnam Kalamkari being block-printed in Andhra, a Kanchipuram silk being weighted with gold zari, a Pochampalli ikat being tied before it ever touches the loom, a Dharmavaram silk, a Gadwal cotton-silk, a Mangalagiri, a Venkatagiri, a Narayanpet, a Bobbili veena. A Mysore silk, a Bidri inlay of silver on blackened-zinc in Karnataka, a Channapatna lacquered toy, a Ilkal saree. In Tamil Nadu, a Thanjavur painting layered in gold leaf, a Swamimalai bronze cast in the lost-wax tradition of the Cholas, a Madurai Sungudi tie-dye, a Toda red-and-black embroidery in the Nilgiris. In Kerala, an Aranmula Kannadi metal mirror, a Kuthampully cotton with kasavu border, a Screw Pine mat woven on the floor.</p>
        <p>In the northeast, a Muga silk in Assam glowing gold without a single dye, an Eri silk in peace-silk, a Majuli mask carved on the river-island, a Sualkuchi loom never stopping. A Naga shawl on a backstrap loom in Mohon, a Manipuri Wangkhei Phee, a Mizo Puanchei, a Tripura Risa, an Apatani textile in Arunachal, a Khasi shawl in Meghalaya, a Mishing weave by a riverbank. Hyderabad lac bangles being dipped in colour, Firozabad bangles being blown in glass, Moradabad brass being hammered by a man whose grandfather hammered the same metal in the same hand-position. Kannauj attar being distilled from the first monsoon rain. Khurja blue pottery turning on a wheel. Saharanpur rosewood being carved by lamplight. Aranmula, Bidri, Dhokra, Pattachitra, Pichhwai, Tanjore, Warli, Pithora, Kalighat, Kerala mural, Basohli, Pahari, Gond, and a hundred more names most catalogues never bother to print.</p>
        <p>But every search led me to either: (1) a five-thousand-rupee mass-produced copy, or (2) a thirty-thousand-rupee designer interpretation. Never the thing itself. Never the hands that made it.</p>
        <p>So I started travelling. Three years. Eighteen states. Two hundred and forty artisan clusters. Weavers, potters, carpenters, metalsmiths, dyers, embroiderers, perfumers, leather-workers, lamp-makers. And I found that the rare, the rooted, the personal still exists. It is just quiet. And the noise of glass-fronted malls and over-lit digital aisles was never going to find it.</p>
        <p>NEEJEE is the place I built for all of them. Every piece is found, personal, and named. The maker is named. The region is named. The technique is named. We do not own the artisans. We partner with them. We pay them in advance and on time. We never compromise on the thing itself.</p>
        <p className="font-display italic text-2xl text-mitti">One place. One spotlight. One honest price. For every pair of hands India has forgotten to celebrate.</p>
      </section>

      <section className="max-w-8xl mx-auto px-6 py-20 grid lg:grid-cols-3 gap-8">
        {[
          { label: 'FOUNDED', value: '2026', note: 'Mumbai · Varanasi · Jaipur' },
          { label: 'ARTISAN PARTNERS', value: '240+', note: 'Across 18 states' },
          { label: 'FAIR-TRADE', value: '100%', note: 'Above MSP · Paid in advance' },
        ].map(s => (
          <div key={s.label} className="text-center p-8 bg-beige">
            <p className="label text-madder">{s.label}</p>
            <p className="font-display text-5xl text-kohl mt-3">{s.value}</p>
            <p className="font-italic italic text-mitti mt-2">{s.note}</p>
          </div>
        ))}
      </section>

      <section className="max-w-2xl mx-auto px-6 py-20 text-center">
        <Link href="/" className="btn-primary inline-block">Begin Finding</Link>
      </section>
      <Footer />
    </>
  );
}
