'use client';
// v23.40.26.1 — Mega-menu navigation. Fetches taxonomy tree from /api/admin/taxonomy
// (public read of active categories) and renders 3-col flyout per main category on hover.
import { useEffect, useState } from 'react';
import Link from 'next/link';

type Cat = {
  id: string; slug: string; name: string; parentId: string | null;
  level: number; path: string | null; active: boolean; hidden: boolean;
};
type TreeNode = Cat & { children: TreeNode[] };

const FALLBACK_MAINS = [
  { slug: 'women', name: 'Women' },
  { slug: 'men', name: 'Men' },
  { slug: 'jewellery', name: 'Jewellery' },
  { slug: 'accessories', name: 'Accessories' },
  { slug: 'home', name: 'Home' },
  { slug: 'fragrance', name: 'Fragrance' },
  { slug: 'gifting', name: 'Gifting' },
];

export function MegaMenuNav() {
  const [tree, setTree] = useState<TreeNode[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Public taxonomy fetch (active + not hidden categories only)
    fetch('/api/categories/tree', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : { tree: [] })
      .then(d => { setTree(d.tree || []); setLoaded(true); })
      .catch(() => setLoaded(true));
  }, []);

  // Show only main categories that exist in the tree; if tree is empty (DB not seeded yet), use fallback.
  const mains: { slug: string; name: string; path?: string | null; node?: TreeNode }[] =
    tree.length > 0
      ? tree.filter(t => t.level === 1).map(t => ({ slug: t.path || t.slug, name: t.name, path: t.path, node: t }))
      : FALLBACK_MAINS;

  return (
    <nav className="hidden lg:flex gap-8 items-center font-ui text-xs tracking-widest text-kohl">
      {mains.map(m => {
        const hasChildren = !!m.node?.children?.length;
        return (
          <div
            key={m.slug}
            className="relative"
            onMouseEnter={() => hasChildren && setOpenId(m.node!.id)}
            onMouseLeave={() => setOpenId(null)}
          >
            <Link href={`/categories/${m.path || m.slug}`} className="hover:text-madder transition-colors py-6">
              {m.name.toUpperCase()}
            </Link>
            {hasChildren && openId === m.node!.id && (
              <MegaMenuFlyout node={m.node!} onClose={() => setOpenId(null)} />
            )}
          </div>
        );
      })}
      <Link href="/journal" className="hover:text-madder transition-colors">STORIES</Link>
      <Link href="/ai" className="hover:text-madder transition-colors text-madder font-medium">AI ✦</Link>
      {!loaded && <span className="sr-only">Loading menu…</span>}
    </nav>
  );
}

function MegaMenuFlyout({ node, onClose }: { node: TreeNode; onClose: () => void }) {
  const subs = (node.children || []).filter(c => c.active && !c.hidden);
  if (subs.length === 0) return null;
  return (
    <div
      className="fixed left-0 right-0 top-[64px] bg-ivory border-t border-beige shadow-lg z-40"
      onMouseLeave={onClose}
    >
      <div className="max-w-8xl mx-auto px-12 py-10">
        <div className="mb-6">
          <p className="label text-madder tracking-[0.3em]">{node.name.toUpperCase()}</p>
          <Link href={`/categories/${node.path || node.slug}`} className="font-display text-2xl text-kohl hover:text-madder mt-1 inline-block" onClick={onClose}>
            Shop all {node.name} →
          </Link>
        </div>
        <div className="grid grid-cols-4 gap-x-10 gap-y-6">
          {subs.map(sub => {
            const leaves = (sub.children || []).filter(c => c.active && !c.hidden).slice(0, 8);
            return (
              <div key={sub.id}>
                <Link
                  href={`/categories/${sub.path || sub.slug}`}
                  onClick={onClose}
                  className="font-display text-base text-kohl hover:text-madder block mb-3"
                >
                  {sub.name}
                </Link>
                <ul className="space-y-1.5">
                  {leaves.map(leaf => (
                    <li key={leaf.id}>
                      <Link
                        href={`/categories/${leaf.path || leaf.slug}`}
                        onClick={onClose}
                        className="font-body text-xs text-mitti hover:text-madder transition-colors"
                      >
                        {leaf.name}
                      </Link>
                    </li>
                  ))}
                  {(sub.children?.filter(c => c.active && !c.hidden).length || 0) > 8 && (
                    <li>
                      <Link href={`/categories/${sub.path || sub.slug}`} onClick={onClose}
                        className="font-body text-xs italic text-madder hover:underline">
                        See all →
                      </Link>
                    </li>
                  )}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
