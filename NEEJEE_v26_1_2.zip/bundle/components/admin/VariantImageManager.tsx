'use client';
// VariantImageManager \u2014 manages per-variant images on the Images tab of the
// admin product editor.
//
// For each variant (e.g. "Red bangle", "Green bangle"):
//   \u2022 Show current Variant.images thumbnails (or "no images yet")
//   \u2022 Upload tile to add raw phone shots
//   \u2022 Per-variant "Generate AI photos for THIS variant" button
//
// At the top, a master "GENERATE FOR ALL VARIANTS IN PARALLEL" button that
// kicks off N jobs at once (one per variant that has raw shots queued).
//
// Two upload modes per variant:
//   1. Direct images \u2014 admin uploads finished studio shots (rare); saved
//      straight to Variant.images via PUT /images endpoint
//   2. Raw shots for AI \u2014 admin uploads phone shots; clicking GENERATE creates
//      an AiPhotoJob scoped to this variant, AI photos go to Variant.images

import { useEffect, useState } from 'react';
import {
  Loader2, Camera, X, Sparkles, RefreshCw, Plus,
  CheckCircle2, AlertCircle,
} from 'lucide-react';

export type VariantRow = {
  id: string;
  sku: string;
  color: string | null;
  colorHex: string | null;
  size: string | null;
  material: string | null;
  images: string[];
};

export type VariantImageManagerProps = {
  productId: string;
  productName?: string;
  categoryName?: string;
  variants: VariantRow[];
  onVariantImagesChanged?: (variantId: string, images: string[]) => void;
};

// Per-variant local state for the upload queue and AI generation
type StagedRawShots = Record<string /* variantId */, string[] /* fal urls */>;

const STYLE_OPTIONS = [
  { value: 'editorial', label: 'Editorial' },
  { value: 'minimal', label: 'Minimal' },
  { value: 'festive', label: 'Festive' },
  { value: 'heritage', label: 'Heritage' },
];

const MODEL_OPTIONS = [
  { value: 'mixed', label: 'Mixed (all archetypes)' },
  { value: 'warm', label: 'Warm \u2014 wheat-toned' },
  { value: 'cool', label: 'Cool \u2014 fair-toned' },
  { value: 'festive', label: 'Festive \u2014 bridal' },
  { value: 'mannequin', label: 'Mannequin only' },
];

export default function VariantImageManager({
  productId,
  productName,
  categoryName,
  variants,
  onVariantImagesChanged,
}: VariantImageManagerProps) {
  // Local in-memory state for raw phone shots per variant (not yet sent to AI)
  const [staged, setStaged] = useState<StagedRawShots>({});
  const [uploading, setUploading] = useState<Record<string, boolean>>({});
  const [running, setRunning] = useState(false);
  const [variantRunning, setVariantRunning] = useState<Record<string, boolean>>({});
  const [stylePreset, setStylePreset] = useState('editorial');
  const [modelArchetype, setModelArchetype] = useState('mixed');
  const [variantCount, setVariantCount] = useState(6);
  const [lastBulkResult, setLastBulkResult] = useState<any>(null);
  // Latest job per variant (with PENDING variants for review). Keyed by variantId.
  const [variantJobs, setVariantJobs] = useState<Record<string, any>>({});
  // Per-variant selection set for APPLY
  const [variantSelections, setVariantSelections] = useState<Record<string, Set<string>>>({});
  const [applying, setApplying] = useState<Record<string, boolean>>({});
  // Local mirror of variant images so the grid updates without a page reload
  const [variantImages, setVariantImages] = useState<Record<string, string[]>>(() => {
    const m: Record<string, string[]> = {};
    variants.forEach(v => { m[v.id] = v.images || []; });
    return m;
  });

  // Re-sync if variants prop changes (e.g. after adding/removing a variant)
  useEffect(() => {
    const m: Record<string, string[]> = {};
    variants.forEach(v => { m[v.id] = v.images || []; });
    setVariantImages(m);
  }, [variants]);

  // Load latest job per variant on mount and after generations
  async function loadLatestJobForVariant(variantId: string) {
    try {
      const res = await fetch(`/api/admin/ai-photo-studio/jobs?productId=${productId}&variantId=${variantId}`, { credentials: 'include' });
      const data = await res.json();
      const latest = (data.jobs || [])[0];
      setVariantJobs(prev => ({ ...prev, [variantId]: latest || null }));
    } catch {}
  }

  async function loadAllVariantJobs() {
    await Promise.all(variants.map(v => loadLatestJobForVariant(v.id)));
  }

  useEffect(() => {
    loadAllVariantJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId, variants.length]);

  function toggleVariantSelection(variantId: string, photoVariantId: string) {
    setVariantSelections(prev => {
      const cur = new Set(prev[variantId] || []);
      if (cur.has(photoVariantId)) cur.delete(photoVariantId);
      else cur.add(photoVariantId);
      return { ...prev, [variantId]: cur };
    });
  }

  async function applyVariantSelections(variantId: string) {
    const job = variantJobs[variantId];
    const ids = Array.from(variantSelections[variantId] || []);
    if (!job || ids.length === 0) return;
    setApplying(prev => ({ ...prev, [variantId]: true }));
    try {
      const res = await fetch(`/api/admin/ai-photo-studio/jobs/${job.id}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ approvedVariantIds: ids }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Apply failed');
        return;
      }
      const newImages: string[] = data.newImages || [];
      // Update local mirror so the variant gallery refreshes instantly
      setVariantImages(prev => ({ ...prev, [variantId]: newImages }));
      onVariantImagesChanged?.(variantId, newImages);
      // Clear selection and reload job for fresh decisions
      setVariantSelections(prev => ({ ...prev, [variantId]: new Set() }));
      await loadLatestJobForVariant(variantId);
      alert(`\u2705 Applied ${ids.length} photo(s) to this variant.`);
    } finally {
      setApplying(prev => ({ ...prev, [variantId]: false }));
    }
  }

  async function reapplyApprovedForVariant(variantId: string) {
    const job = variantJobs[variantId];
    if (!job) return;
    setApplying(prev => ({ ...prev, [variantId]: true }));
    try {
      const res = await fetch(`/api/admin/ai-photo-studio/jobs/${job.id}/reapply`, {
        method: 'POST',
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Re-apply failed');
        return;
      }
      const newImages: string[] = data.newImages || [];
      setVariantImages(prev => ({ ...prev, [variantId]: newImages }));
      onVariantImagesChanged?.(variantId, newImages);
    } finally {
      setApplying(prev => ({ ...prev, [variantId]: false }));
    }
  }

  async function uploadRawShot(variantId: string, file: File) {
    setUploading(prev => ({ ...prev, [variantId]: true }));
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('folder', `ai-photo-studio/raw/${variantId}`);
      const res = await fetch('/api/admin/upload', { method: 'POST', body: fd, credentials: 'include' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        alert(data?.error || 'Upload failed');
        return;
      }
      const url = data?.url || data?.files?.[0]?.url;
      if (url) {
        setStaged(prev => ({ ...prev, [variantId]: [...(prev[variantId] || []), url] }));
      }
    } finally {
      setUploading(prev => ({ ...prev, [variantId]: false }));
    }
  }

  // Bulk upload — multiple files in one go (up to 5 per call to be polite to
  // the storage layer). Uses Promise.all for parallel uploads but in batches.
  async function uploadRawShotBulk(variantId: string, files: FileList | File[]) {
    const list = Array.from(files);
    if (list.length === 0) return;
    setUploading(prev => ({ ...prev, [variantId]: true }));
    try {
      const BATCH = 5;
      const collected: string[] = [];
      for (let i = 0; i < list.length; i += BATCH) {
        const slice = list.slice(i, i + BATCH);
        const results = await Promise.all(slice.map(async file => {
          const fd = new FormData();
          fd.append('file', file);
          fd.append('folder', `ai-photo-studio/raw/${variantId}`);
          try {
            const res = await fetch('/api/admin/upload', { method: 'POST', body: fd, credentials: 'include' });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
              console.warn('[variant-upload]', file.name, data?.error || res.status);
              return null;
            }
            return data?.url || data?.files?.[0]?.url || null;
          } catch (e) {
            console.warn('[variant-upload] exception', file.name, e);
            return null;
          }
        }));
        for (const u of results) if (u) collected.push(u);
      }
      if (collected.length > 0) {
        setStaged(prev => ({ ...prev, [variantId]: [...(prev[variantId] || []), ...collected] }));
      }
      const failed = list.length - collected.length;
      if (failed > 0) alert(`Uploaded ${collected.length}/${list.length}. ${failed} failed (see console).`);
    } finally {
      setUploading(prev => ({ ...prev, [variantId]: false }));
    }
  }

  function removeStaged(variantId: string, idx: number) {
    setStaged(prev => ({
      ...prev,
      [variantId]: (prev[variantId] || []).filter((_, i) => i !== idx),
    }));
  }

  async function generateForVariant(variantId: string) {
    const sources = staged[variantId] || [];
    if (sources.length === 0) {
      alert('Upload at least one raw phone shot for this variant first.');
      return;
    }
    if (!confirm(`Generate ${variantCount} AI photos for this variant? ~$${(variantCount * 0.04).toFixed(2)} of fal credits. Takes 2\u20133 min.`)) {
      return;
    }
    setVariantRunning(prev => ({ ...prev, [variantId]: true }));
    try {
      const res = await fetch('/api/admin/ai-photo-studio/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          productId,
          variantId,
          sourceImageUrls: sources,
          categoryName,
          productName,
          variantCount,
          modelArchetype,
          stylePreset,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        alert(data.error || data.result?.firstError || 'Generation failed');
        return;
      }
      alert(`\u2705 Generated ${data.result?.variantCount || 0} AI photos. Select and APPLY below.`);
      // Clear staged for this variant after a successful generation
      setStaged(prev => ({ ...prev, [variantId]: [] }));
      // Refresh the latest job to surface the new PENDING variants
      await loadLatestJobForVariant(variantId);
    } finally {
      setVariantRunning(prev => ({ ...prev, [variantId]: false }));
    }
  }

  async function generateForAll() {
    const queue = variants
      .filter(v => (staged[v.id] || []).length > 0)
      .map(v => ({ variantId: v.id, sourceImageUrls: staged[v.id] }));
    if (queue.length === 0) {
      alert('Upload at least one raw phone shot for at least one variant first.');
      return;
    }
    const totalCost = (queue.length * variantCount * 0.04).toFixed(2);
    if (!confirm(`Generate ${variantCount} AI photos for ${queue.length} variant(s) in parallel? ~$${totalCost} of fal credits. Takes 3\u20135 min.`)) {
      return;
    }
    setRunning(true);
    setLastBulkResult(null);
    try {
      const res = await fetch('/api/admin/ai-photo-studio/bulk-variants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          productId,
          variants: queue,
          variantCount,
          modelArchetype,
          stylePreset,
        }),
      });
      const data = await res.json();
      setLastBulkResult(data);
      if (!res.ok) {
        alert(data.error || 'Bulk generation failed');
        return;
      }
      alert(`\u2705 ${data.summary || 'Bulk generation done'}. Each variant card below now shows photos to review and apply.`);
      // Clear staged for the variants that succeeded
      const okIds = (data.jobs || []).filter((j: any) => j.ok).map((j: any) => j.variantId);
      setStaged(prev => {
        const next = { ...prev };
        for (const id of okIds) next[id] = [];
        return next;
      });
      // Refresh all variant jobs so the per-variant review grids appear
      await loadAllVariantJobs();
    } finally {
      setRunning(false);
    }
  }

  // Remove a single image directly from a variant's gallery
  async function removeVariantImage(variantId: string, idx: number) {
    const current = variantImages[variantId] || [];
    const next = current.filter((_, i) => i !== idx);
    const res = await fetch(`/api/admin/products/${productId}/variants/${variantId}/images`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ images: next }),
    });
    if (!res.ok) {
      alert('Failed to remove image');
      return;
    }
    setVariantImages(prev => ({ ...prev, [variantId]: next }));
    onVariantImagesChanged?.(variantId, next);
  }

  if (variants.length === 0) {
    return (
      <div className="border border-mitti/20 bg-ivory p-5 text-sm text-mitti">
        Add variants on the Inventory tab to manage per-variant (colour/size) imagery.
      </div>
    );
  }

  const totalStaged = Object.values(staged).reduce((s, arr) => s + arr.length, 0);

  return (
    <div className="border border-mitti/20 bg-ivory">
      <div className="px-4 py-3 border-b border-mitti/15 bg-beige/40 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-mitti" />
          <h3 className="font-display text-base text-kohl uppercase tracking-wider">Per-Variant Images</h3>
        </div>
        <button
          type="button"
          onClick={generateForAll}
          disabled={running || totalStaged === 0}
          className="btn-primary text-xs inline-flex items-center gap-2 disabled:opacity-50"
          title="Generate AI photos for every variant that has staged raw shots, in parallel"
        >
          {running ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          {running ? 'GENERATING ALL\u2026' : `GENERATE FOR ALL (${totalStaged} staged)`}
        </button>
      </div>

      <div className="p-4 space-y-3">
        {/* Shared options for variant-scope jobs */}
        <div className="grid md:grid-cols-3 gap-3 pb-3 border-b border-mitti/10">
          <label className="text-xs uppercase block">
            Model
            <select value={modelArchetype} onChange={e => setModelArchetype(e.target.value)} className="w-full mt-1 p-2 border border-mitti/20 text-sm normal-case bg-beige">
              {MODEL_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </label>
          <label className="text-xs uppercase block">
            Style
            <select value={stylePreset} onChange={e => setStylePreset(e.target.value)} className="w-full mt-1 p-2 border border-mitti/20 text-sm normal-case bg-beige">
              {STYLE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </label>
          <label className="text-xs uppercase block">
            Photos per variant
            <select value={variantCount} onChange={e => setVariantCount(Number(e.target.value))} className="w-full mt-1 p-2 border border-mitti/20 text-sm normal-case bg-beige">
              <option value={3}>3 (~$0.12/variant)</option>
              <option value={4}>4 (~$0.16/variant)</option>
              <option value={6}>6 (~$0.24/variant) \u2014 recommended</option>
            </select>
          </label>
        </div>

        {lastBulkResult?.jobs && (
          <div className="bg-beige/40 border border-mitti/15 p-3 text-xs space-y-1">
            <div className="font-display text-sm">Last bulk run</div>
            {lastBulkResult.jobs.map((j: any) => (
              <div key={j.variantId} className="flex items-center gap-2">
                {j.ok ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                ) : (
                  <AlertCircle className="w-3 h-3 text-rose-700" />
                )}
                <span className={j.ok ? 'text-emerald-800' : 'text-rose-800'}>
                  {j.variantLabel || j.variantId}: {j.ok ? `${j.variantCount} photos` : (j.firstError || 'failed')}
                </span>
              </div>
            ))}
          </div>
        )}

        {variants.map(v => {
          const swatch = v.colorHex || '#cccccc';
          const staged_v = staged[v.id] || [];
          const current_v = variantImages[v.id] || [];
          const isUploading_v = !!uploading[v.id];
          const isRunning_v = !!variantRunning[v.id];
          return (
            <div key={v.id} className="border border-mitti/15 p-3">
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="inline-block w-4 h-4 rounded-full border border-mitti/30" style={{ background: swatch }} />
                  <div>
                    <div className="font-display text-sm text-kohl">
                      {v.color || 'Default'}
                      {v.size && <span className="text-mitti"> / {v.size}</span>}
                      {v.material && <span className="text-mitti"> / {v.material}</span>}
                    </div>
                    <div className="text-[10px] font-mono text-mitti">{v.sku}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => generateForVariant(v.id)}
                  disabled={isRunning_v || running || staged_v.length === 0}
                  className="btn-outline text-xs inline-flex items-center gap-1 disabled:opacity-50"
                  title="Generate AI photos for this variant only"
                >
                  {isRunning_v ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  GENERATE
                </button>
              </div>

              {/* Current variant images */}
              {current_v.length > 0 && (
                <div className="mb-3">
                  <div className="text-[10px] uppercase text-charcoal/50 mb-1">Live gallery ({current_v.length})</div>
                  <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                    {current_v.map((url, i) => (
                      <div key={i} className="relative group">
                        <img src={url} alt="" className="w-full aspect-square object-cover border border-mitti/15" />
                        <button
                          type="button"
                          onClick={() => removeVariantImage(v.id, i)}
                          className="absolute top-1 right-1 bg-black/60 text-white p-1 opacity-0 group-hover:opacity-100"
                          title="Remove from variant gallery"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI-generated variants from latest job — select & apply */}
              {(() => {
                const job = variantJobs[v.id];
                if (!job || !Array.isArray(job.variants) || job.variants.length === 0) return null;
                const selSet = variantSelections[v.id] || new Set<string>();
                const pending = job.variants.filter((pv: any) => pv.decision === 'PENDING');
                const approved = job.variants.filter((pv: any) => pv.decision === 'APPROVED');
                const isApplying = !!applying[v.id];
                return (
                  <div className="mb-3 border border-madder/30 bg-madder/5 p-2">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-[10px] uppercase tracking-widest text-madder font-ui">
                        AI photos — {job.status} · {pending.length} pending · {approved.length} approved
                      </div>
                      <div className="flex gap-1">
                        {approved.length > 0 && current_v.length === 0 && (
                          <button type="button" onClick={() => reapplyApprovedForVariant(v.id)} disabled={isApplying}
                            className="text-[10px] font-ui tracking-widest border border-kohl text-kohl px-2 py-0.5 hover:bg-kohl hover:text-ivory disabled:opacity-50">
                            RE-APPLY APPROVED
                          </button>
                        )}
                        {selSet.size > 0 && (
                          <button type="button" onClick={() => applyVariantSelections(v.id)} disabled={isApplying}
                            className="text-[10px] font-ui tracking-widest bg-madder text-ivory px-2 py-0.5 hover:bg-kohl disabled:opacity-50">
                            APPLY {selSet.size}
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-1">
                      {job.variants.map((pv: any) => {
                        const selected = selSet.has(pv.id);
                        const isApproved = pv.decision === 'APPROVED';
                        const isRejected = pv.decision === 'REJECTED';
                        return (
                          <button key={pv.id} type="button" onClick={() => toggleVariantSelection(v.id, pv.id)}
                            className={`relative aspect-square overflow-hidden border-2 ${selected ? 'border-madder' : isApproved ? 'border-emerald-500/50' : isRejected ? 'border-stone-300 opacity-50' : 'border-mitti/20'}`}
                            title={pv.sceneType || ''}>
                            <img src={pv.url} alt="" className="w-full h-full object-cover" />
                            {selected && (
                              <span className="absolute top-0.5 right-0.5 bg-madder text-ivory text-[9px] font-ui px-1">✓</span>
                            )}
                            {isApproved && !selected && (
                              <span className="absolute top-0.5 right-0.5 bg-emerald-600 text-ivory text-[9px] font-ui px-1">APPROVED</span>
                            )}
                            {isRejected && (
                              <span className="absolute top-0.5 right-0.5 bg-stone-600 text-ivory text-[9px] font-ui px-1">REJ</span>
                            )}
                            {pv.sceneType && (
                              <span className="absolute bottom-0 left-0 right-0 bg-black/50 text-ivory text-[9px] font-ui px-1 py-0.5 truncate">{pv.sceneType}</span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* Staged raw shots */}
              <div>
                <div className="text-[10px] uppercase text-charcoal/50 mb-1">
                  Raw phone shots {staged_v.length > 0 && `(${staged_v.length} staged \u2014 not yet sent to AI)`}
                </div>
                <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                  {staged_v.map((url, i) => (
                    <div key={i} className="relative group">
                      <img src={url} alt="" className="w-full aspect-square object-cover border-2 border-dashed border-madder/40" />
                      <button
                        type="button"
                        onClick={() => removeStaged(v.id, i)}
                        className="absolute top-1 right-1 bg-black/60 text-white p-1 opacity-0 group-hover:opacity-100"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <label className="aspect-square border-2 border-dashed border-mitti/30 flex flex-col items-center justify-center text-xs text-mitti hover:border-madder cursor-pointer">
                    {isUploading_v ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                      <>
                        <Camera className="w-4 h-4 mb-1" />
                        <span>Add</span>
                        <span className="text-[9px] text-mitti">(multi)</span>
                      </>
                    )}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      multiple
                      className="hidden"
                      onChange={e => {
                        const files = e.target.files;
                        if (files && files.length > 0) {
                          if (files.length === 1) uploadRawShot(v.id, files[0]);
                          else uploadRawShotBulk(v.id, files);
                        }
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>
                {current_v.length === 0 && staged_v.length === 0 && (
                  <p className="text-[10px] text-charcoal/50 italic mt-1">
                    No images yet for this variant. Customers will see the shared Product gallery as fallback.
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
