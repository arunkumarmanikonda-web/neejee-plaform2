// v23.40.26.1 — Edge middleware for category slug redirects.
// Reads CategoryRedirect table (via API) and 301s old slugs to new paths.
// Runs at the edge — no DB connection here, calls /api/categories/redirect.
import { NextResponse, NextRequest } from 'next/server';

const TRAILING_SLASH = /\/+$/;

export async function middleware(request: NextRequest) {
  const { pathname, origin } = request.nextUrl;

  // Only handle /categories/* paths
  if (!pathname.startsWith('/categories/')) return NextResponse.next();

  const slug = pathname.replace('/categories/', '').replace(TRAILING_SLASH, '');
  if (!slug) return NextResponse.next();

  // If slug already contains a slash, it's a multi-level path — let the catch-all handle it.
  // We only redirect old flat slugs (no slashes) here.
  if (slug.includes('/')) return NextResponse.next();

  try {
    // Use the redirect lookup API. Fetch with no-cache so we always get the latest mapping.
    const r = await fetch(`${origin}/api/categories/redirect?slug=${encodeURIComponent(slug)}`, {
      cache: 'no-store',
      // Avoid loops — middleware will not re-fire for /api/* paths
    });
    if (!r.ok) return NextResponse.next();
    const data = await r.json();
    if (data?.found && data?.toSlug) {
      const newPath = `/categories/${data.toSlug}${request.nextUrl.search || ''}`;
      const status = data.permanent ? 308 : 307; // preserve method on POST etc.
      return NextResponse.redirect(new URL(newPath, request.url), status);
    }
  } catch {
    // On any failure, just continue — don't break the user's request
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/categories/:path*'],
};
