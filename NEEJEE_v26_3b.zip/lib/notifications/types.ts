// lib/notifications/types.ts
// v26.3b — Shared types for the multi-channel notification stack.

export type Channel = 'email' | 'sms' | 'whatsapp';

export type NotificationEvent =
  // Cart recovery
  | 'CART_T1H'
  | 'CART_T24H'
  | 'CART_T72H'
  | 'TELECALLER_HANDOFF'
  // Auth
  | 'OTP_LOGIN'
  | 'OTP_SIGNUP'
  // Order lifecycle
  | 'ORDER_PLACED'
  | 'ORDER_SHIPPED'
  | 'ORDER_OUT_FOR_DELIVERY'
  | 'ORDER_DELIVERED'
  | 'ORDER_CANCELLED';

export type DispatchStatus = 'queued' | 'sent' | 'delivered' | 'read' | 'failed';

export interface DispatchRecord {
  id: string;
  channel: Channel;
  event: NotificationEvent;
  templateName: string;
  recipient: string;          // phone (E.164) or email
  userId?: string | null;
  orderId?: string | null;
  cartId?: string | null;
  variables: Record<string, string>;
  attempt?: number;
  maxAttempts?: number;
}

export interface ChannelSendResult {
  ok: boolean;
  providerRequestId?: string;
  providerResponse?: any;
  errorMessage?: string;
  permanentFailure?: boolean;  // if true, no retry
}

export interface ChannelAdapter {
  name: string;                // 'fast2sms' | 'aisensy'
  channel: Channel;            // 'sms' | 'whatsapp'
  isConfigured(): boolean;
  send(dispatch: DispatchRecord): Promise<ChannelSendResult>;
}
