# Patch instructions for app/(auth)/signup/page.tsx — v26.3b

Same pattern as the login patch: add a Phone tab alongside the existing
Email signup form. PhoneOtpForm handles name + email + phone + OTP in one flow.

## Drop-in replacement

```tsx
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import PhoneOtpForm from '@/components/auth/PhoneOtpForm';

export default function SignupPage() {
  const router = useRouter();
  const [tab, setTab] = useState<'phone' | 'email'>('phone');
  // Phone-first is the new default. Email tab still available for those who prefer it.

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <h1 className="font-display text-3xl text-center text-kohl">Welcome to NEEJEE</h1>
        <p className="text-center italic text-mitti mt-1">The atelier opens its doors.</p>

        <div className="flex border-b border-mitti/30 mt-8">
          <button
            onClick={() => setTab('phone')}
            className={`flex-1 py-3 text-sm uppercase tracking-widest ${
              tab === 'phone' ? 'text-kohl border-b-2 border-madder' : 'text-mitti'
            }`}
          >Phone</button>
          <button
            onClick={() => setTab('email')}
            className={`flex-1 py-3 text-sm uppercase tracking-widest ${
              tab === 'email' ? 'text-kohl border-b-2 border-madder' : 'text-mitti'
            }`}
          >Email</button>
        </div>

        <div className="mt-8">
          {tab === 'phone' && (
            <PhoneOtpForm
              purpose="signup"
              onSuccess={() => router.push('/account/welcome')}
            />
          )}
          {tab === 'email' && (
            <div>
              {/* PASTE YOUR EXISTING EMAIL SIGNUP FORM HERE */}
            </div>
          )}
        </div>

        <p className="text-center text-sm text-mitti mt-8">
          Already with us? <a href="/login" className="text-madder underline">Sign in</a>
        </p>
      </div>
    </main>
  );
}
```
