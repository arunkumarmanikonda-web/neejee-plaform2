# Patch instructions for app/(auth)/login/page.tsx — v26.3b

This file already exists from earlier sprints (email/password + OAuth). We need to
ADD a "Phone OTP" tab without removing existing functionality.

## Two-tab layout

The page should render two tabs at the top: **Email** (existing) and **Phone**.

## Drop-in replacement (recommended)

If you'd prefer to overwrite, here's the full file:

```tsx
'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import PhoneOtpForm from '@/components/auth/PhoneOtpForm';
// NOTE: keep your existing imports for the Email form

export default function LoginPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const next = sp?.get('next') || '/account';
  const [tab, setTab] = useState<'email' | 'phone'>('email');

  const onPhoneSuccess = (user: any) => {
    router.push(next);
  };

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <h1 className="font-display text-3xl text-center text-kohl">Welcome back</h1>
        <p className="text-center italic text-mitti mt-1">Your trunk awaits.</p>

        {/* Tabs */}
        <div className="flex border-b border-mitti/30 mt-8">
          <button
            type="button"
            onClick={() => setTab('email')}
            className={`flex-1 py-3 text-sm uppercase tracking-widest ${
              tab === 'email' ? 'text-kohl border-b-2 border-madder' : 'text-mitti'
            }`}
          >Email</button>
          <button
            type="button"
            onClick={() => setTab('phone')}
            className={`flex-1 py-3 text-sm uppercase tracking-widest ${
              tab === 'phone' ? 'text-kohl border-b-2 border-madder' : 'text-mitti'
            }`}
          >Phone</button>
        </div>

        <div className="mt-8">
          {tab === 'email' && (
            <div>
              {/* PASTE YOUR EXISTING EMAIL LOGIN FORM HERE */}
              {/* It used to live at the root of the LoginPage return — move
                  it into this block, unchanged. */}
            </div>
          )}
          {tab === 'phone' && (
            <PhoneOtpForm purpose="login" onSuccess={onPhoneSuccess} />
          )}
        </div>

        <p className="text-center text-sm text-mitti mt-8">
          New to NEEJEE? <a href="/signup" className="text-madder underline">Create an account</a>
        </p>
      </div>
    </main>
  );
}
```

## Minimal-touch alternative

If you don't want to refactor:

1. Open `app/(auth)/login/page.tsx`
2. At the top, add: `import PhoneOtpForm from '@/components/auth/PhoneOtpForm';`
3. Add state: `const [tab, setTab] = useState<'email' | 'phone'>('email');`
4. Wrap your existing form in `{tab === 'email' && (<>...your form...</>)}`
5. Add `{tab === 'phone' && <PhoneOtpForm purpose="login" onSuccess={(u) => router.push('/account')} />}`
6. Add the 2 tab buttons above the form area.

That's it — your email/password and OAuth flows stay exactly as they were.
