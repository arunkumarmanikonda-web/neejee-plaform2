# NEEJEE v23.40.28.0 (Wave 26.3b) — Deployment Guide

## What this wave delivers

1. **Phone OTP authentication** — login + signup via SMS OTP (alongside existing email)
2. **Multi-channel cart recovery** — adds SMS + WhatsApp dispatch on top of Wave 26.3a's email-only flow
3. **Order lifecycle notifications** — every order status change (placed/shipped/OFD/delivered/cancelled) fires SMS + WhatsApp + email
4. **Notification audit log** — admin can see every dispatch with delivery & read receipts
5. **Template registry** — admin can paste in DLT IDs + AiSensy template names as they get approved
6. **A/B testing framework** — built but disabled by default; activate later in `/admin/recovery-settings`

---

## ⚠️ Prerequisites

This wave assumes Wave 26.3a is already deployed and the Nidhi-bug smoke test has passed.

If you haven't run that smoke test yet, **do it before deploying 26.3b** — otherwise we're stacking on a possibly-broken foundation.

---

## Files in this zip (~28 files, ~4500 lines)

```
prisma/SPRINT_26_3B_MIGRATION.sql

# Notifications core
lib/notifications/types.ts
lib/notifications/dispatcher.ts
lib/notifications/order-events.ts
lib/notifications/channels/fast2sms.ts
lib/notifications/channels/aisensy.ts

# Auth (phone OTP)
lib/auth/otp.ts
app/api/auth/otp/request/route.ts
app/api/auth/otp/verify/route.ts
app/api/auth/otp/resend/route.ts
components/auth/PhoneOtpForm.tsx
app/(auth)/login/page.tsx.PATCH.md       ← manual 2-edit patch
app/(auth)/signup/page.tsx.PATCH.md      ← manual 2-edit patch

# Webhooks
app/api/webhooks/fast2sms/route.ts
app/api/webhooks/aisensy/route.ts
app/api/webhooks/shiprocket/route.ts

# Cart recovery cron — REPLACES the 26.3a cron
app/api/cron/cart-recovery/route.ts

# Admin UI
app/api/admin/notification-templates/route.ts
app/admin/notification-templates/page.tsx
app/api/admin/notification-dispatches/route.ts
app/admin/notification-dispatches/page.tsx

# A/B framework
lib/ab/assign.ts

# Integration patches for files we don't replace fully
INTEGRATION_PATCHES.md

# Deploy guide
DEPLOY_v26_3b.md
```

---

## Deployment steps

### Step 1 — SQL migration

In Supabase SQL editor, paste `prisma/SPRINT_26_3B_MIGRATION.sql` → Run. Verify these results:

- `User new cols: 3`
- `NotificationDispatch exists: 1`
- `NotificationTemplate seed count: 17`
- `AbTest tables: 3`

### Step 2 — Drop in the code files

```powershell
cd C:\Users\arunk\OneDrive\Desktop\neejee-v6

# Download the v26.3b zip (URL will be provided in chat)
curl.exe -L -o NEEJEE_v26_3b.zip "<URL>"

# Extract and copy
Expand-Archive .\NEEJEE_v26_3b.zip -DestinationPath .\v26_3b_extracted -Force
robocopy .\v26_3b_extracted . /E /XF "*.PATCH.md" "DEPLOY_v26_3b.md" "INTEGRATION_PATCHES.md"

# Verify key files landed
Test-Path .\lib\notifications\dispatcher.ts
Test-Path .\lib\auth\otp.ts
Test-Path .\app\api\auth\otp\request\route.ts
Test-Path .\prisma\SPRINT_26_3B_MIGRATION.sql
```

### Step 3 — Apply manual patches

Open these 5 files and follow the inline patches in:
- `app/(auth)/login/page.tsx.PATCH.md` (add Phone tab)
- `app/(auth)/signup/page.tsx.PATCH.md` (add Phone tab)
- `INTEGRATION_PATCHES.md` (5 short additions to checkout/route.ts, razorpay/verify, admin orders, shiprocket, cron — but the cron is fully replaced, so skip cron in INTEGRATION_PATCHES.md)

### Step 4 — Update Prisma schema

Add the new models to `prisma/schema.prisma`. After the existing `AbandonedCart` model, append:

```prisma
model NotificationDispatch {
  id                    String   @id @default(cuid())
  channel               String
  event                 String
  templateName          String
  recipient             String
  userId                String?
  orderId               String?
  cartId                String?
  providerRequestId     String?
  status                String   @default("queued")
  errorMessage          String?
  attempt               Int      @default(1)
  maxAttempts           Int      @default(3)
  nextRetryAt           DateTime?
  payloadJson           Json?
  providerResponseJson  Json?
  sentAt                DateTime?
  deliveredAt           DateTime?
  readAt                DateTime?
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt
  @@index([status, nextRetryAt])
  @@index([channel, event])
  @@index([userId])
  @@index([orderId])
  @@index([cartId])
  @@index([providerRequestId])
}

model NotificationTemplate {
  id                  String   @id @default(cuid())
  key                 String   @unique
  channel             String
  providerTemplateId  String?
  providerName        String
  displayName         String
  bodyPreview         String?
  variableCount       Int      @default(0)
  approvalStatus      String   @default("pending")
  enabled             Boolean  @default(true)
  lastUsedAt          DateTime?
  createdAt           DateTime @default(now())
  updatedAt           DateTime @updatedAt
}

model AbTest {
  id          String      @id @default(cuid())
  key         String      @unique
  displayName String
  enabled     Boolean     @default(false)
  startedAt   DateTime?
  endedAt     DateTime?
  createdAt   DateTime    @default(now())
  variants    AbVariant[]
  assignments AbAssignment[]
}

model AbVariant {
  id            String   @id @default(cuid())
  abTestId      String
  abTest        AbTest   @relation(fields: [abTestId], references: [id], onDelete: Cascade)
  key           String
  displayName   String
  payloadJson   Json
  weight        Int      @default(50)
  createdAt     DateTime @default(now())
  assignments   AbAssignment[]
  @@unique([abTestId, key])
}

model AbAssignment {
  id                    String   @id @default(cuid())
  abTestId              String
  abTest                AbTest   @relation(fields: [abTestId], references: [id], onDelete: Cascade)
  variantId             String
  variant               AbVariant @relation(fields: [variantId], references: [id], onDelete: Cascade)
  subjectKey            String
  subjectType           String
  exposedAt             DateTime @default(now())
  convertedAt           DateTime?
  conversionValuePaise  Int?
  @@unique([abTestId, subjectKey])
  @@index([subjectKey, subjectType])
}
```

And extend the `User` model (add these fields):
```prisma
  phoneVerified       Boolean   @default(false)
  phoneVerifiedAt     DateTime?
  primaryAuthMethod   String?
```

And extend the `RecoverySettings` model:
```prisma
  channelMatrix       Json      @default("{\"stage1\":{\"email\":true,\"sms\":false,\"whatsapp\":false},\"stage2\":{\"email\":true,\"sms\":false,\"whatsapp\":true},\"stage3\":{\"email\":true,\"sms\":false,\"whatsapp\":true},\"stage4\":{\"email\":true,\"sms\":true,\"whatsapp\":false}}")
```

Run `npx prisma generate`.

### Step 5 — Environment variables (Vercel → Production)

Add these. SMS/WA channels stay dormant until both API key + template ID are present.

```
# Fast2SMS
FAST2SMS_API_KEY=
FAST2SMS_SENDER_ID=NEEJEY
FAST2SMS_BASE_URL=https://www.fast2sms.com/dev/bulkV2

# Per-template DLT IDs (paste once each is approved)
FAST2SMS_TPL_T1H_NUDGE=
FAST2SMS_TPL_T24H_KARIGAR=
FAST2SMS_TPL_T72H_FAREWELL=
FAST2SMS_TPL_TELECALLER=
FAST2SMS_TPL_OTP=
FAST2SMS_TPL_ORDER_PLACED=
FAST2SMS_TPL_ORDER_SHIPPED=
FAST2SMS_TPL_OFD=
FAST2SMS_TPL_DELIVERED=
FAST2SMS_TPL_CANCELLED=

# AiSensy
AISENSY_API_KEY=
AISENSY_API_URL=https://backend.aisensy.com/campaign/t1/api/v2
WHATSAPP_BUSINESS_NUMBER=

# Telecaller alerts
TELECALLER_TEAM_PHONE=+919876543210
TELECALLER_TEAM_EMAIL=telecaller@neejee.com
```

### Step 6 — Configure provider webhooks

**Fast2SMS** → Dashboard → DLT Manager → Webhooks → Delivery Reports URL:
```
https://www.neejee.com/api/webhooks/fast2sms
```

**AiSensy** → Manage → Webhooks → Message Status Webhook:
```
https://www.neejee.com/api/webhooks/aisensy
```

**Shiprocket** (if not done already) → Settings → Webhooks:
```
https://www.neejee.com/api/webhooks/shiprocket
```

### Step 7 — TypeScript check + deploy

```powershell
npx tsc --noEmit 2>&1 | Select-Object -First 80
# If clean, deploy:
vercel --prod --force
```

---

## Smoke tests after deploy

### Test 1 — Phone OTP login
1. Open `/login` in incognito
2. Click **Phone** tab
3. Enter your test phone number → Continue
4. Receive SMS with 6-digit code (check Fast2SMS dashboard if not received)
5. Enter code → should log in to `/account`

### Test 2 — Phone OTP signup
1. Open `/signup` in incognito
2. Click **Phone** tab
3. Enter name, optional email, and a NEW phone number
4. Receive OTP, enter, verify
5. New user account created with `phoneVerified=true`

### Test 3 — Order placed notifications (COD)
1. Place a COD order
2. Customer phone should receive:
   - SMS-T6 Order Placed via Fast2SMS
   - WA-T3 order_placed via AiSensy
   - Existing order-received email
3. Check `/admin/notification-dispatches` — should show 2 rows (1 SMS, 1 WA) with status=`sent` or `delivered`

### Test 4 — Order shipped (manual admin trigger)
1. In admin, set an order's status to SHIPPED, add an AWB number
2. Customer should receive SMS-T7 + WA-T4 within seconds
3. Check audit log

### Test 5 — Recovery cron with multi-channel
1. Manually set a cart's `nextActionAt = NOW()` and `createdAt = NOW() - INTERVAL '40 minutes'`, `recoveryStage = 1`
2. Trigger cron: `curl -H "Authorization: Bearer $CRON_SECRET" https://www.neejee.com/api/cron/cart-recovery`
3. Cart should receive recovery email (existing) + WhatsApp WA-T1 (if cart has a phone)

### Test 6 — Template registry
1. Open `/admin/notification-templates`
2. See all 17 templates listed with status=`pending`
3. Paste DLT IDs into each row, set status to `approved`, click Save
4. Verify the saved IDs come back on reload

### Test 7 — Webhook delivery receipts
1. After a successful SMS, wait 5-10 seconds
2. Refresh `/admin/notification-dispatches`
3. Row status should flip from `sent` to `delivered`
4. Same flow for WhatsApp once AiSensy posts back

---

## Rollback plan

The migration is fully additive. To roll back code:
- Restore previous deployment via Vercel dashboard ("Promote to production" on an older deploy)
- No DB rollback needed; new columns/tables can sit unused

---

## Activation order (recommended)

Don't try to flip everything on at once. Stagger:

1. **Day 0** — deploy code with all env vars EMPTY. Nothing breaks because adapters silently skip when unconfigured.
2. **Day 1** — fill in Fast2SMS env vars + 1 DLT template ID (OTP). Test phone OTP login.
3. **Day 2** — add remaining DLT template IDs. Place a test order, verify SMS arrives.
4. **Day 3** — add AiSensy env vars + first WhatsApp template approval. Test order on AiSensy.
5. **Day 4** — add remaining WhatsApp template approvals.
6. **Week 2** — flip cart recovery WhatsApp channel ON in `/admin/recovery-settings`.
7. **Week 4** — enable first A/B test in `/admin` (UI to come in Wave 26.3c if needed).

This gives every channel a clean, isolated debug window.
