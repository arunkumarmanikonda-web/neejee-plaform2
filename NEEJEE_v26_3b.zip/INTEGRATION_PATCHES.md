# Wave 26.3b — Integration patches for existing files

These are short, surgical additions to existing files. Each section is a
copy-paste patch — no full file replacement needed.

---

## 1. `app/api/checkout/route.ts` — Fire ORDER_PLACED on COD

**Where**: Inside the `if (payment === 'COD') {...}` branch, AFTER the existing
email notification block (the `try { const { notify } ... } catch ...` block
that fires `ORDER_PLACED` email). Append this:

```ts
      // v26.3b — Fire SMS + WhatsApp for COD order
      try {
        const { fireOrderEvent } = await import('@/lib/notifications/order-events');
        fireOrderEvent({ orderId: order.id, event: 'ORDER_PLACED' })
          .catch(e => console.warn('[checkout COD] notification fanout failed:', e?.message));
      } catch (e: any) {
        console.warn('[checkout COD] fireOrderEvent import failed:', e?.message);
      }
```

(Use `.catch` — fire-and-forget. We never want a notification failure to break
the order placement HTTP response.)

---

## 2. `app/api/razorpay/verify/route.ts` — Fire ORDER_PLACED on prepaid

**Where**: Inside the prepaid success branch (where the snapshot is converted
to an Order and `notify({ event: 'ORDER_CONFIRMED', ... })` is called for the
email). Append:

```ts
      // v26.3b — Fire SMS + WhatsApp for prepaid order
      try {
        const { fireOrderEvent } = await import('@/lib/notifications/order-events');
        fireOrderEvent({ orderId: order.id, event: 'ORDER_PLACED' })
          .catch(e => console.warn('[razorpay verify] notification fanout failed:', e?.message));
      } catch (e: any) {
        console.warn('[razorpay verify] fireOrderEvent import failed:', e?.message);
      }
```

Place this right after the existing `notify({ event: 'ORDER_CONFIRMED' ... })` try/catch.

---

## 3. `app/api/admin/orders/[id]/route.ts` — Fire on status change

**Where**: Find the PATCH handler that updates order status. After
`prisma.order.update(...)` succeeds, inspect what changed and call
fireOrderEvent for the matching event.

```ts
// v26.3b — On status change, fire matching notifications
async function fireStatusChangeNotification(orderId: string, oldStatus: string, newStatus: string) {
  if (oldStatus === newStatus) return;
  const eventMap: Record<string, string> = {
    SHIPPED:           'ORDER_SHIPPED',
    OUT_FOR_DELIVERY:  'ORDER_OUT_FOR_DELIVERY',
    DELIVERED:         'ORDER_DELIVERED',
    CANCELLED:         'ORDER_CANCELLED',
  };
  const event = eventMap[newStatus];
  if (!event) return;
  try {
    const { fireOrderEvent } = await import('@/lib/notifications/order-events');
    await fireOrderEvent({ orderId, event: event as any });
  } catch (e: any) {
    console.warn('[admin.orders.status] notification failed:', e?.message);
  }
}
```

Then in your PATCH handler, after a successful update:
```ts
const updated = await prisma.order.update({ where: { id }, data: { status: body.status, ... } });
// v26.3b
fireStatusChangeNotification(updated.id, oldOrder.status, updated.status).catch(() => {});
```

---

## 4. `app/api/webhooks/shiprocket/route.ts` — Auto-fire on tracking updates

**Where**: If this file already exists, find the section that updates order
status based on Shiprocket's tracking webhook payload. Add the same
`fireStatusChangeNotification` call. If the file doesn't exist yet, the
skeleton is included in this zip at `app/api/webhooks/shiprocket/route.ts`.

---

## 5. `app/api/cron/cart-recovery/route.ts` — Multi-channel fanout

**Where**: Replace the stage-1/2/3 send blocks. Instead of just calling
`sendEmail`, the cron should also dispatch SMS + WhatsApp per the
channel matrix in RecoverySettings.channelMatrix.

The full updated cron is included in this zip at the same path. Diff is
substantial — recommend overwriting the whole file from the zip.
